import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import '../constants.dart';

class BankTransferService {
  static final BankTransferService _instance = BankTransferService._internal();
  factory BankTransferService() => _instance;
  BankTransferService._internal();

  // APIs للتحويل البنكي
  static const String _wiseApiUrl = 'https://api.wise.com/v1';
  static const String _exchangeRateApiUrl = 'https://api.exchangerate-api.com/v4/latest';
  static const String _currencyFreaksUrl = 'https://api.currencyfreaks.com/v2.0/rates/latest';

  // مفاتيح API (يجب استبدالها بمفاتيح حقيقية)
  static const String _wiseApiKey = 'YOUR_WISE_API_KEY';
  static const String _currencyFreaksApiKey = 'YOUR_CURRENCYFREAKS_API_KEY';

  /// الحصول على سعر الصرف الحالي EGP -> JOD
  static Future<double> getExchangeRate() async {
    try {
      // محاولة 1: CurrencyFreaks API (أكثر دقة)
      final response = await http.get(
        Uri.parse('$_currencyFreaksUrl?apikey=$_currencyFreaksApiKey&symbols=JOD,EGP'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final egpRate = double.parse(data['rates']['EGP'].toString());
        final jodRate = double.parse(data['rates']['JOD'].toString());

        // JOD/EGP = (USD/EGP) / (USD/JOD)
        return egpRate / jodRate;
      }

      // محاولة 2: ExchangeRate-API (مجاني)
      final fallbackResponse = await http.get(
        Uri.parse('$_exchangeRateApiUrl/EGP'),
      );

      if (fallbackResponse.statusCode == 200) {
        final data = jsonDecode(fallbackResponse.body);
        return data['rates']['JOD'] ?? 0.0133; // سعر افتراضي
      }

      return 0.0133; // سعر افتراضي احتياطي
    } catch (e) {
      debugPrint('Error fetching exchange rate: $e');
      return 0.0133; // سعر افتراضي
    }
  }

  /// تحويل مبلغ من EGP إلى JOD
  static Future<Map<String, dynamic>> convertEgpToJod(double egpAmount) async {
    final rate = await getExchangeRate();
    final jodAmount = egpAmount * rate;

    return {
      'egpAmount': egpAmount,
      'jodAmount': jodAmount,
      'rate': rate,
      'timestamp': DateTime.now().toIso8601String(),
    };
  }

  /// إنشاء تحويل بنكي عبر Wise
  static Future<Map<String, dynamic>?> createWiseTransfer({
    required double jodAmount,
    required String recipientName,
    required String recipientIban,
    required String recipientBank,
    required String reference,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$_wiseApiUrl/transfers'),
        headers: {
          'Authorization': 'Bearer $_wiseApiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'targetCurrency': 'JOD',
          'sourceCurrency': 'EGP',
          'targetAmount': jodAmount,
          'profile': 'your-profile-id',
          'quoteUuid': 'your-quote-uuid',
          'details': {
            'reference': reference,
          },
        }),
      );

      if (response.statusCode == 201) {
        return jsonDecode(response.body);
      }
      return null;
    } catch (e) {
      debugPrint('Error creating Wise transfer: $e');
      return null;
    }
  }

  /// إنشاء مستلم (Recipient) في Wise
  static Future<Map<String, dynamic>?> createWiseRecipient({
    required String name,
    required String iban,
    required String bankName,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$_wiseApiUrl/accounts'),
        headers: {
          'Authorization': 'Bearer $_wiseApiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'currency': 'JOD',
          'type': 'iban',
          'profile': 'your-profile-id',
          'accountHolderName': name,
          'details': {
            'iban': iban,
            'bankName': bankName,
          },
        }),
      );

      if (response.statusCode == 201) {
        return jsonDecode(response.body);
      }
      return null;
    } catch (e) {
      debugPrint('Error creating Wise recipient: $e');
      return null;
    }
  }

  /// التحقق من حالة التحويل
  static Future<Map<String, dynamic>?> checkTransferStatus(String transferId) async {
    try {
      final response = await http.get(
        Uri.parse('$_wiseApiUrl/transfers/$transferId'),
        headers: {
          'Authorization': 'Bearer $_wiseApiKey',
        },
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
      return null;
    } catch (e) {
      debugPrint('Error checking transfer status: $e');
      return null;
    }
  }

  /// حساب رسوم التحويل
  static Future<Map<String, dynamic>> calculateFees(double egpAmount) async {
    final rate = await getExchangeRate();
    final jodAmount = egpAmount * rate;

    // رسوم Wise (تقريبية)
    final wiseFee = egpAmount * 0.005; // 0.5%
    final bankFee = 50; // رسوم بنكية ثابتة (EGP)

    return {
      'originalAmount': egpAmount,
      'convertedAmount': jodAmount,
      'exchangeRate': rate,
      'wiseFee': wiseFee,
      'bankFee': bankFee,
      'totalFees': wiseFee + bankFee,
      'netAmount': egpAmount - wiseFee - bankFee,
      'netJodAmount': (egpAmount - wiseFee - bankFee) * rate,
    };
  }
}
