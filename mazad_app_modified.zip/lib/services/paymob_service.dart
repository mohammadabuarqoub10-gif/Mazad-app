import 'package:flutter/material.dart';
import 'package:flutter_paymob/flutter_paymob.dart';
import '../constants.dart';

class PaymobService {
  static final PaymobService _instance = PaymobService._internal();
  factory PaymobService() => _instance;
  PaymobService._internal();

  bool _isInitialized = false;

  /// تهيئة Paymob
  Future<void> initialize() async {
    if (_isInitialized) return;

    FlutterPaymob.instance.initialize(
      apiKey: AppConstants.paymobApiKey,
      integrationID: int.parse(AppConstants.paymobIntegrationId),
      walletIntegrationId: int.parse(AppConstants.paymobWalletIntegrationId),
      iFrameID: int.parse(AppConstants.paymobIframeId),
    );

    _isInitialized = true;
  }

  /// الدفع بالبطاقة
  Future<PaymobResponse> payWithCard({
    required BuildContext context,
    required double amount,
    required String currency,
  }) async {
    await initialize();

    return FlutterPaymob.instance.payWithCard(
      context: context,
      currency: currency,
      amount: amount,
      onPayment: (response) {
        debugPrint('Payment Response: ${response.toJson()}');
      },
    );
  }

  /// الدفع بالمحفظة الإلكترونية
  Future<PaymobResponse> payWithWallet({
    required BuildContext context,
    required double amount,
    required String currency,
    required String phoneNumber,
  }) async {
    await initialize();

    return FlutterPaymob.instance.payWithWallet(
      context: context,
      currency: currency,
      amount: amount,
      number: phoneNumber,
      onPayment: (response) {
        debugPrint('Wallet Payment Response: ${response.toJson()}');
      },
    );
  }

  /// التحقق من حالة الدفع
  bool isPaymentSuccessful(PaymobResponse response) {
    return response.success == true;
  }

  /// الحصول على معرف المعاملة
  String? getTransactionId(PaymobResponse response) {
    return response.transactionID;
  }
}

/// امتداد لـ PaymobResponse لإضافة toJson
extension PaymobResponseExtension on PaymobResponse {
  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'transactionID': transactionID,
      'responseCode': responseCode,
      'message': message,
    };
  }
}
