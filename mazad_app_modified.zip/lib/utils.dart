import 'package:intl/intl.dart';
import 'package:flutter/material.dart';

class AppUtils {
  // تنسيق المبالغ المالية
  static String formatCurrency(double amount, {String currency = 'EGP'}) {
    final formatter = NumberFormat('#,##0.00');
    return '${formatter.format(amount)} $currency';
  }

  // تنسيق التاريخ
  static String formatDate(DateTime date) {
    return DateFormat('yyyy/MM/dd').format(date);
  }

  // تنسيق الوقت
  static String formatTime(DateTime date) {
    return DateFormat('HH:mm').format(date);
  }

  // تنسيق التاريخ والوقت
  static String formatDateTime(DateTime date) {
    return DateFormat('yyyy/MM/dd HH:mm').format(date);
  }

  // تنسيق الوقت المتبقي
  static String formatRemainingTime(Duration duration) {
    if (duration.isNegative) return 'انتهى';

    final days = duration.inDays;
    final hours = duration.inHours % 24;
    final minutes = duration.inMinutes % 60;
    final seconds = duration.inSeconds % 60;

    if (days > 0) {
      return '$days يوم ${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}';
    }
    return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  // تحويل EGP إلى JOD
  static double egpToJod(double egpAmount) {
    return egpAmount * 0.0228;
  }

  // تحويل JOD إلى EGP
  static double jodToEgp(double jodAmount) {
    return jodAmount / 0.0228;
  }

  // حساب العمولة (1%)
  static double calculateCommission(double amount) {
    return amount * 0.01;
  }

  // حساب صافي البائع
  static double calculateSellerAmount(double amount) {
    return amount * 0.99; // 100% - 1% commission
  }

  // التحقق من صحة رقم الهاتف المصري
  static bool isValidEgyptianPhone(String phone) {
    // يجب أن يبدأ بـ +20 أو 0020 أو 01
    final cleanPhone = phone.replaceAll(RegExp(r'\s+'), '');
    return RegExp(r'^(\+20|0020|01)[0-9]{9,10}$').hasMatch(cleanPhone);
  }

  // تنظيف رقم الهاتف
  static String cleanPhoneNumber(String phone) {
    return phone.replaceAll(RegExp(r'[^0-9+]'), '');
  }

  // عرض SnackBar
  static void showSnackBar(BuildContext context, String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  // عرض Dialog
  static Future<bool> showConfirmDialog(
    BuildContext context, {
    required String title,
    required String message,
    String confirmText = 'تأكيد',
    String cancelText = 'إلغاء',
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(cancelText),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF6B4EE6),
            ),
            child: Text(confirmText),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  // التحقق من الاتصال بالإنترنت
  static Future<bool> checkInternetConnection() async {
    // يمكن استخدام connectivity_plus
    return true; // placeholder
  }
}
