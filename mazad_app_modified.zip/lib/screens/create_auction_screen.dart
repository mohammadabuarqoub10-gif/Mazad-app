import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../providers/auction_provider.dart';
import '../providers/auth_provider.dart';

class CreateAuctionScreen extends StatefulWidget {
  const CreateAuctionScreen({super.key});

  @override
  State<CreateAuctionScreen> createState() => _CreateAuctionScreenState();
}

class _CreateAuctionScreenState extends State<CreateAuctionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();
  final _locationController = TextEditingController();

  String _selectedCategory = 'أخرى';
  String _selectedCondition = 'مستعمل';
  int _durationHours = 24;
  List<File> _selectedImages = [];
  bool _isCreating = false;

  final List<String> _categories = [
    'سيارات',
    'عقارات',
    'إلكترونيات',
    'أثاث',
    'ملابس',
    'تحف',
    'أخرى',
  ];

  final List<String> _conditions = ['جديد', 'مستعمل', 'مستعمل بحالة جيدة'];

  @override
  Widget build(BuildContext context) {
    final auctionProvider = Provider.of<AuctionProvider>(context);
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('إنشاء مزاد جديد'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // صور المنتج
            Text(
              'صور المنتج',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),

            SizedBox(
              height: 120,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _selectedImages.length + 1,
                itemBuilder: (context, index) {
                  if (index == _selectedImages.length) {
                    return GestureDetector(
                      onTap: _pickImages,
                      child: Container(
                        width: 120,
                        margin: const EdgeInsets.only(left: 8),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.grey[300]!,
                            style: BorderStyle.solid,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.add_photo_alternate,
                              size: 40,
                              color: Colors.grey[600],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'إضافة صورة',
                              style: TextStyle(color: Colors.grey[600]),
                            ),
                          ],
                        ),
                      ),
                    );
                  }

                  return Stack(
                    children: [
                      Container(
                        width: 120,
                        margin: const EdgeInsets.only(left: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          image: DecorationImage(
                            image: FileImage(_selectedImages[index]),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      Positioned(
                        top: 4,
                        right: 4,
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedImages.removeAt(index);
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: const BoxDecoration(
                              color: Colors.red,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.close,
                              size: 16,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),

            const SizedBox(height: 24),

            // العنوان
            TextFormField(
              controller: _titleController,
              decoration: InputDecoration(
                labelText: 'اسم المنتج *',
                hintText: 'مثال: iPhone 14 Pro Max',
                prefixIcon: const Icon(Icons.label_outline),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'اسم المنتج مطلوب';
                }
                return null;
              },
            ),

            const SizedBox(height: 16),

            // الفئة
            DropdownButtonFormField<String>(
              value: _selectedCategory,
              decoration: InputDecoration(
                labelText: 'الفئة *',
                prefixIcon: const Icon(Icons.category_outlined),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              items: _categories.map((category) {
                return DropdownMenuItem(
                  value: category,
                  child: Text(category),
                );
              }).toList(),
              onChanged: (value) {
                setState(() => _selectedCategory = value!);
              },
            ),

            const SizedBox(height: 16),

            // الحالة
            DropdownButtonFormField<String>(
              value: _selectedCondition,
              decoration: InputDecoration(
                labelText: 'حالة المنتج *',
                prefixIcon: const Icon(Icons.check_circle_outline),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              items: _conditions.map((condition) {
                return DropdownMenuItem(
                  value: condition,
                  child: Text(condition),
                );
              }).toList(),
              onChanged: (value) {
                setState(() => _selectedCondition = value!);
              },
            ),

            const SizedBox(height: 16),

            // السعر الابتدائي
            TextFormField(
              controller: _priceController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'السعر الابتدائي (ج.م) *',
                hintText: 'مثال: 5000',
                prefixIcon: const Icon(Icons.attach_money),
                suffixText: 'ج.م',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'السعر الابتدائي مطلوب';
                }
                if (double.tryParse(value) == null || double.parse(value) <= 0) {
                  return 'أدخل سعر صحيح';
                }
                return null;
              },
            ),

            const SizedBox(height: 16),

            // مدة المزاد
            DropdownButtonFormField<int>(
              value: _durationHours,
              decoration: InputDecoration(
                labelText: 'مدة المزاد *',
                prefixIcon: const Icon(Icons.timer_outlined),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              items: [
                const DropdownMenuItem(value: 1, child: Text('1 ساعة')),
                const DropdownMenuItem(value: 6, child: Text('6 ساعات')),
                const DropdownMenuItem(value: 12, child: Text('12 ساعة')),
                const DropdownMenuItem(value: 24, child: Text('يوم واحد')),
                const DropdownMenuItem(value: 48, child: Text('يومين')),
                const DropdownMenuItem(value: 72, child: Text('3 أيام')),
                const DropdownMenuItem(value: 168, child: Text('أسبوع')),
              ],
              onChanged: (value) {
                setState(() => _durationHours = value!);
              },
            ),

            const SizedBox(height: 16),

            // الموقع
            TextFormField(
              controller: _locationController,
              decoration: InputDecoration(
                labelText: 'الموقع *',
                hintText: 'مثال: القاهرة، مصر الجديدة',
                prefixIcon: const Icon(Icons.location_on_outlined),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'الموقع مطلوب';
                }
                return null;
              },
            ),

            const SizedBox(height: 16),

            // الوصف
            TextFormField(
              controller: _descriptionController,
              maxLines: 4,
              decoration: InputDecoration(
                labelText: 'وصف المنتج *',
                hintText: 'اكتب وصفاً تفصيلياً للمنتج...',
                prefixIcon: const Icon(Icons.description_outlined),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'الوصف مطلوب';
                }
                if (value.length < 20) {
                  return 'الوصف يجب أن يكون 20 حرفاً على الأقل';
                }
                return null;
              },
            ),

            const SizedBox(height: 24),

            // معلومات العمولة
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF6B4EE6).withOpacity(0.1),
                    const Color(0xFF6B4EE6).withOpacity(0.05),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: const Color(0xFF6B4EE6).withOpacity(0.3),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.info_outline,
                        color: const Color(0xFF6B4EE6),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'عمولة التطبيق: 1% فقط',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF6B4EE6),
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'عند بيع منتجك، سنخصص 1% فقط من قيمة المزاد كعمولة للتطبيق.',
                    style: TextStyle(color: Colors.grey[700]),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'مثال: إذا بعت بـ 10,000 ج.م، العمولة 100 ج.م فقط.',
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 32),

            // زر الإنشاء
            SizedBox(
              height: 56,
              child: ElevatedButton(
                onPressed: _isCreating || auctionProvider.isLoading
                    ? null
                    : () => _createAuction(auctionProvider, authProvider),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF6B4EE6),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: _isCreating || auctionProvider.isLoading
                    ? const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(width: 12),
                          Text('جاري الإنشاء...'),
                        ],
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.gavel),
                          SizedBox(width: 8),
                          Text(
                            'نشر المزاد',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
              ),
            ),

            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImages() async {
    final picker = ImagePicker();
    final images = await picker.pickMultiImage();

    if (images != null) {
      setState(() {
        _selectedImages.addAll(images.map((img) => File(img.path)));
      });
    }
  }

  Future<void> _createAuction(
    AuctionProvider auctionProvider,
    AuthProvider authProvider,
  ) async {
    if (!_formKey.currentState!.validate()) return;

    if (!authProvider.isLoggedIn) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('يجب تسجيل الدخول أولاً'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() => _isCreating = true);

    // Placeholder for Firebase Storage upload implementation
    final imageUrls = <String>[];
    // for (var image in _selectedImages) {
    //   final url = await uploadImage(image);
    //   imageUrls.add(url);
    // }

    final success = await auctionProvider.createAuction(
      title: _titleController.text,
      description: _descriptionController.text,
      images: imageUrls,
      startPrice: double.parse(_priceController.text),
      endTime: DateTime.now().add(Duration(hours: _durationHours)),
      category: _selectedCategory,
      condition: _selectedCondition,
      location: _locationController.text,
    );

    setState(() => _isCreating = false);

    if (success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم نشر المزاد بنجاح!'),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(auctionProvider.error ?? 'فشل نشر المزاد'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    _locationController.dispose();
    super.dispose();
  }
}
