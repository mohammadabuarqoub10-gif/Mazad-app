import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/auth_provider.dart';
import '../providers/payment_provider.dart';
import 'login_screen.dart';
import 'bank_settings_screen.dart';
import 'transfer_history_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<PaymentProvider>(context, listen: false).loadUserTransactions();
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final paymentProvider = Provider.of<PaymentProvider>(context);
    final user = authProvider.userModel;

    if (!authProvider.isLoggedIn) {
      return Scaffold(
        appBar: AppBar(title: const Text('حسابي')),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.person_off, size: 80, color: Colors.grey[300]),
              const SizedBox(height: 16),
              const Text('يجب تسجيل الدخول أولاً'),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                  );
                },
                child: const Text('تسجيل الدخول'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // صورة الملف الشخصي
          Center(
            child: Stack(
              children: [
                CircleAvatar(
                  radius: 60,
                  backgroundColor: const Color(0xFF6B4EE6),
                  child: Text(
                    user?.name[0] ?? 'م',
                    style: const TextStyle(
                      fontSize: 40,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                if (user?.isVerified ?? false)
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(
                        color: Colors.green,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.verified,
                        size: 20,
                        color: Colors.white,
                      ),
                    ),
                  ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // الاسم
          Text(
            user?.name ?? 'مستخدم',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 4),

          // الهاتف
          Text(
            user?.phone ?? '',
            style: TextStyle(color: Colors.grey[600]),
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 24),

          // قسم التحويل البنكي
          _buildBankSection(),

          const SizedBox(height: 24),

          // الإحصائيات
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                  icon: Icons.gavel,
                  title: 'مزادات منشورة',
                  value: '${user?.auctionsCreated ?? 0}',
                  color: Colors.blue,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildStatCard(
                  icon: Icons.emoji_events,
                  title: 'مزادات فائز',
                  value: '${user?.auctionsWon ?? 0}',
                  color: Colors.amber,
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // قائمة الخيارات
          _buildMenuSection(
            title: 'الحساب',
            items: [
              _MenuItem(
                icon: Icons.edit,
                title: 'تعديل الملف الشخصي',
                onTap: () {},
              ),
              _MenuItem(
                icon: Icons.verified_user,
                title: 'توثيق الحساب',
                subtitle: user?.isVerified ?? false ? 'موثق' : 'غير موثق',
                onTap: () {},
              ),
            ],
          ),

          const SizedBox(height: 16),

          _buildMenuSection(
            title: 'المزادات',
            items: [
              _MenuItem(
                icon: Icons.gavel,
                title: 'مزاداتي',
                onTap: () {},
              ),
              _MenuItem(
                icon: Icons.history,
                title: 'سجل المزايدات',
                onTap: () {},
              ),
            ],
          ),

          const SizedBox(height: 16),

          _buildMenuSection(
            title: 'الدعم',
            items: [
              _MenuItem(
                icon: Icons.help_outline,
                title: 'مركز المساعدة',
                onTap: () {},
              ),
              _MenuItem(
                icon: Icons.policy,
                title: 'شروط الاستخدام',
                onTap: () {},
              ),
            ],
          ),

          const SizedBox(height: 24),

          // تسجيل الخروج
          ElevatedButton.icon(
            onPressed: () async {
              await authProvider.signOut();
              if (mounted) {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                );
              }
            },
            icon: const Icon(Icons.logout),
            label: const Text('تسجيل الخروج'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red[50],
              foregroundColor: Colors.red,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),

          const SizedBox(height: 32),

          // معلومات العمولة
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF6B4EE6).withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                const Icon(
                  Icons.info_outline,
                  color: Color(0xFF6B4EE6),
                ),
                const SizedBox(height: 8),
                Text(
                  'عمولة التطبيق: 1% فقط',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF6B4EE6),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'نأخذ 1% فقط من قيمة كل مزاد ناجح',
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 12,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBankSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.green[50]!,
            Colors.green[100]!,
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green[300]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.account_balance, color: Colors.green[700]),
              const SizedBox(width: 8),
              Text(
                'التحويل البنكي',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.green[800],
                  fontSize: 16,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'تحويل العمولات تلقائياً إلى حسابك البنكي في الأردن',
            style: TextStyle(color: Colors.green[700]),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const BankSettingsScreen()),
                    );
                  },
                  icon: const Icon(Icons.settings),
                  label: const Text('الإعدادات'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green[600],
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const TransferHistoryScreen()),
                    );
                  },
                  icon: const Icon(Icons.history),
                  label: const Text('السجل'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.green[700],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 32),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuSection({
    required String title,
    required List<_MenuItem> items,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: Colors.grey[800],
          ),
        ),
        const SizedBox(height: 8),
        Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: Colors.grey[200]!),
          ),
          child: Column(
            children: items.map((item) {
              return ListTile(
                leading: Icon(item.icon, color: const Color(0xFF6B4EE6)),
                title: Text(item.title),
                subtitle: item.subtitle != null
                    ? Text(item.subtitle!)
                    : null,
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: item.onTap,
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}

class _MenuItem {
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback onTap;

  _MenuItem({
    required this.icon,
    required this.title,
    this.subtitle,
    required this.onTap,
  });
}
