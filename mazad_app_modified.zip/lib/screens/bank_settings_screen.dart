import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/bank_transfer_service.dart';
import '../providers/auth_provider.dart';

class BankSettingsScreen extends StatefulWidget {
  const BankSettingsScreen({super.key});

  @override
  State<BankSettingsScreen> createState() => _BankSettingsScreenState();
}

class _BankSettingsScreenState extends State<BankSettingsScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _ibanController = TextEditingController();
  final _bankNameController = TextEditingController();
  final _accountNumberController = TextEditingController();

  bool _isLoading = false;
  bool _autoConvert = true; // تحويل تلقائي
  bool _autoTransfer = false; // تحويل تلقائي للبنك
  double _minTransferAmount = 1000; // الحد الأدنى للتحويل

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إعدادات الحساب البنكي'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // معلومات التحويل التلقائي
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      const Color(0xFF6B4EE6).withOpacity(0.1),
                      const Color(0xFF6B4EE6).withOpacity(0.05),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: const Color(0xFF6B4EE6).withOpacity(0.3),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.account_balance,
                          color: const Color(0xFF6B4EE6),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'التحويل التلقائي إلى الحساب البنكي',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF6B4EE6),
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'سيتم تحويل العمولات تلقائياً من EGP إلى JOD وإرسالها إلى حسابك البنكي في الأردن',
                      style: TextStyle(color: Colors.grey[700]),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // إعدادات التحويل التلقائي
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      SwitchListTile(
                        title: const Text('تحويل تلقائي للعملة'),
                        subtitle: const Text('تحويل EGP إلى JOD تلقائياً'),
                        value: _autoConvert,
                        onChanged: (value) {
                          setState(() => _autoConvert = value);
                        },
                      ),
                      const Divider(),
                      SwitchListTile(
                        title: const Text('تحويل تلقائي للبنك'),
                        subtitle: const Text('إرسال المبالغ إلى حسابك البنكي تلقائياً'),
                        value: _autoTransfer,
                        onChanged: (value) {
                          setState(() => _autoTransfer = value);
                        },
                      ),
                      const Divider(),
                      ListTile(
                        title: const Text('الحد الأدنى للتحويل'),
                        subtitle: Text('$_minTransferAmount JOD'),
                        trailing: IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () => _showMinAmountDialog(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // معلومات الحساب البنكي
              Text(
                'معلومات الحساب البنكي (الأردن)',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'اسم صاحب الحساب *',
                  hintText: 'الاسم كما يظهر في البنك',
                  prefixIcon: const Icon(Icons.person),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'اسم صاحب الحساب مطلوب';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 16),

              TextFormField(
                controller: _bankNameController,
                decoration: InputDecoration(
                  labelText: 'اسم البنك *',
                  hintText: 'مثال: البنك العربي',
                  prefixIcon: const Icon(Icons.account_balance),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'اسم البنك مطلوب';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 16),

              TextFormField(
                controller: _ibanController,
                textDirection: TextDirection.ltr,
                textAlign: TextAlign.left,
                decoration: InputDecoration(
                  labelText: 'IBAN *',
                  hintText: 'JO89 ARAB 0000 0000 0000 0000 0000',
                  prefixIcon: const Icon(Icons.confirmation_number),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  helperText: 'رقم الحساب الدولي (IBAN)',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'IBAN مطلوب';
                  }
                  if (!value.toUpperCase().startsWith('JO')) {
                    return 'IBAN الأردن يجب أن يبدأ بـ JO';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 16),

              TextFormField(
                controller: _accountNumberController,
                textDirection: TextDirection.ltr,
                textAlign: TextAlign.left,
                decoration: InputDecoration(
                  labelText: 'رقم الحساب',
                  hintText: 'رقم الحساب المحلي (اختياري)',
                  prefixIcon: const Icon(Icons.numbers),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // معلومات سعر الصرف
              FutureBuilder(
                future: BankTransferService.getExchangeRate(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.green[50],
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.green[200]!),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.currency_exchange, color: Colors.green[700]),
                              const SizedBox(width: 8),
                              Text(
                                'سعر الصرف الحالي',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.green[800],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '1 EGP = ${snapshot.data?.toStringAsFixed(5)} JOD',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.green[700],
                            ),
                          ),
                          Text(
                            '1 JOD = ${(1 / (snapshot.data ?? 1)).toStringAsFixed(2)} EGP',
                            style: TextStyle(color: Colors.green[600]),
                          ),
                        ],
                      ),
                    );
                  }
                  return const Center(child: CircularProgressIndicator());
                },
              ),

              const SizedBox(height: 24),

              // حاسبة التحويل
              _buildConversionCalculator(),

              const SizedBox(height: 32),

              // زر الحفظ
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _saveSettings,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6B4EE6),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: _isLoading
                      ? const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircularProgressIndicator(color: Colors.white),
                            SizedBox(width: 12),
                            Text('جاري الحفظ...'),
                          ],
                        )
                      : const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.save),
                            SizedBox(width: 8),
                            Text(
                              'حفظ الإعدادات',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildConversionCalculator() {
    final egpController = TextEditingController();
    final jodController = TextEditingController();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'حاسبة التحويل',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: egpController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'المبلغ (EGP)',
                      suffixText: 'ج.م',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onChanged: (value) async {
                      final egp = double.tryParse(value) ?? 0;
                      final result = await BankTransferService.convertEgpToJod(egp);
                      jodController.text = result['jodAmount'].toStringAsFixed(2);
                    },
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Icon(Icons.arrow_forward, color: Colors.grey),
                ),
                Expanded(
                  child: TextField(
                    controller: jodController,
                    readOnly: true,
                    decoration: InputDecoration(
                      labelText: 'المبلغ (JOD)',
                      suffixText: 'د.أ',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      filled: true,
                      fillColor: Colors.grey[100],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showMinAmountDialog() {
    final controller = TextEditingController(text: _minTransferAmount.toString());

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('الحد الأدنى للتحويل'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'المبلغ (JOD)',
            suffixText: 'د.أ',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _minTransferAmount = double.tryParse(controller.text) ?? 1000;
              });
              Navigator.pop(context);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  Future<void> _saveSettings() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    // Placeholder for Firebase save implementation
    // await FirebaseFirestore.instance.collection('users').doc(userId).update({
    //   'bankAccount': {
    //     'name': _nameController.text,
    //     'bankName': _bankNameController.text,
    //     'iban': _ibanController.text,
    //     'accountNumber': _accountNumberController.text,
    //   },
    //   'autoConvert': _autoConvert,
    //   'autoTransfer': _autoTransfer,
    //   'minTransferAmount': _minTransferAmount,
    // });

    await Future.delayed(const Duration(seconds: 2));

    setState(() => _isLoading = false);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم حفظ الإعدادات بنجاح!'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _ibanController.dispose();
    _bankNameController.dispose();
    _accountNumberController.dispose();
    super.dispose();
  }
}
