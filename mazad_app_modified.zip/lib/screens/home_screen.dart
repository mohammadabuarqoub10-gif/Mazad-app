import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../providers/auth_provider.dart';
import '../providers/auction_provider.dart';
import '../widgets/auction_card.dart';
import '../widgets/category_chip.dart';
import 'auction_detail_screen.dart';
import 'create_auction_screen.dart';
import 'profile_screen.dart';
import 'my_auctions_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  String _selectedCategory = 'الكل';

  final List<String> _categories = [
    'الكل',
    'سيارات',
    'عقارات',
    'إلكترونيات',
    'أثاث',
    'ملابس',
    'تحف',
    'أخرى',
  ];

  @override
  Widget build(BuildContext context) {
    final auctionProvider = Provider.of<AuctionProvider>(context);
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('تطبيق مزاد'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {
              // فتح صفحة الإشعارات
            },
          ),
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ProfileScreen()),
              );
            },
          ),
        ],
      ),
      body: _selectedIndex == 0
          ? _buildHomeContent(auctionProvider)
          : _selectedIndex == 1
              ? const MyAuctionsScreen()
              : const ProfileScreen(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        selectedItemColor: const Color(0xFF6B4EE6),
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: 'الرئيسية',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.gavel_outlined),
            activeIcon: Icon(Icons.gavel),
            label: 'مزاداتي',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person),
            label: 'حسابي',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const CreateAuctionScreen()),
          );
        },
        backgroundColor: const Color(0xFF6B4EE6),
        icon: const Icon(Icons.add),
        label: const Text('مزاد جديد'),
      ),
    );
  }

  Widget _buildHomeContent(AuctionProvider provider) {
    return Column(
      children: [
        // شريط البحث
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'ابحث عن مزاد...',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              filled: true,
              fillColor: Colors.grey[100],
            ),
          ),
        ),

        // الفئات
        SizedBox(
          height: 50,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _categories.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(left: 8),
                child: CategoryChip(
                  label: _categories[index],
                  isSelected: _selectedCategory == _categories[index],
                  onTap: () {
                    setState(() => _selectedCategory = _categories[index]);
                  },
                ),
              );
            },
          ),
        ),

        const SizedBox(height: 8),

        // قائمة المزادات
        Expanded(
          child: StreamBuilder<List<Auction>>(
            stream: _selectedCategory == 'الكل'
                ? provider.getActiveAuctionsStream()
                : provider.getAuctionsByCategory(_selectedCategory),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              if (snapshot.hasError) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, size: 64, color: Colors.red[300]),
                      const SizedBox(height: 16),
                      Text('حدث خطأ: ${snapshot.error}'),
                    ],
                  ),
                );
              }

              final auctions = snapshot.data ?? [];

              if (auctions.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.gavel_outlined,
                        size: 80,
                        color: Colors.grey[300],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'لا توجد مزادات نشطة',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey[600],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'كن أول من ينشر مزاد!',
                        style: TextStyle(
                          color: Colors.grey[500],
                        ),
                      ),
                    ],
                  ),
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: auctions.length,
                itemBuilder: (context, index) {
                  return AuctionCard(
                    auction: auctions[index],
                    onTap: () {
                      provider.selectAuction(auctions[index]);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AuctionDetailScreen(
                            auction: auctions[index],
                          ),
                        ),
                      );
                    },
                  )
                      .animate()
                      .fadeIn(duration: 400.ms, delay: (index * 100).ms)
                      .slideY(begin: 0.2, end: 0);
                },
              );
            },
          ),
        ),
      ],
    );
  }
}
