import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auction_provider.dart';
import '../providers/auth_provider.dart';
import '../widgets/auction_card.dart';
import 'auction_detail_screen.dart';

class MyAuctionsScreen extends StatefulWidget {
  const MyAuctionsScreen({super.key});

  @override
  State<MyAuctionsScreen> createState() => _MyAuctionsScreenState();
}

class _MyAuctionsScreenState extends State<MyAuctionsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AuctionProvider>(context, listen: false).loadMyAuctions();
    });
  }

  @override
  Widget build(BuildContext context) {
    final auctionProvider = Provider.of<AuctionProvider>(context);
    final authProvider = Provider.of<AuthProvider>(context);

    if (!authProvider.isLoggedIn) {
      return Scaffold(
        appBar: AppBar(title: const Text('مزاداتي')),
        body: const Center(
          child: Text('يجب تسجيل الدخول أولاً'),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('مزاداتي'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'المنشورة'),
            Tab(text: 'المنتهية'),
            Tab(text: 'المشاركات'),
          ],
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          indicatorColor: Colors.white,
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // المزادات المنشورة النشطة
          _buildAuctionsList(
            auctionProvider.myAuctions.where((a) => a.isLive).toList(),
            'لا توجد مزادات نشطة',
          ),

          // المزادات المنتهية
          _buildAuctionsList(
            auctionProvider.myAuctions.where((a) => !a.isLive).toList(),
            'لا توجد مزادات منتهية',
          ),

          // المزادات التي شاركت فيها
          FutureBuilder(
            future: auctionProvider.loadMyBids(),
            builder: (context, snapshot) {
              return _buildAuctionsList(
                auctionProvider.myBids,
                'لم تشارك في أي مزاد',
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildAuctionsList(List<Auction> auctions, String emptyMessage) {
    if (auctions.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.gavel_outlined,
              size: 80,
              color: Colors.grey[300],
            ),
            const SizedBox(height: 16),
            Text(
              emptyMessage,
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: auctions.length,
      itemBuilder: (context, index) {
        return AuctionCard(
          auction: auctions[index],
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AuctionDetailScreen(auction: auctions[index]),
              ),
            );
          },
        );
      },
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
}
