import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة التحكم - تطبيق مزاد'),
        backgroundColor: const Color(0xFF6B4EE6),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // الإحصائيات العامة
            _buildStatsCards(),
            const SizedBox(height: 32),

            // العمولات
            _buildCommissionSection(),
            const SizedBox(height: 32),

            // المزادات النشطة
            _buildActiveAuctions(),
            const SizedBox(height: 32),

            // المستخدمين
            _buildUsersSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsCards() {
    return StreamBuilder(
      stream: _firestore.collection('auctions').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const CircularProgressIndicator();

        final auctions = snapshot.data!.docs;
        final activeAuctions = auctions.where((a) => a['isActive'] == true).length;
        final completedAuctions = auctions.where((a) => a['isActive'] == false).length;
        final totalBids = auctions.fold<int>(0, (sum, a) => sum + (a['bidCount'] ?? 0));

        return Row(
          children: [
            Expanded(child: _buildStatCard('إجمالي المزادات', auctions.length.toString(), Colors.blue)),
            const SizedBox(width: 16),
            Expanded(child: _buildStatCard('النشطة', activeAuctions.toString(), Colors.green)),
            const SizedBox(width: 16),
            Expanded(child: _buildStatCard('المنتهية', completedAuctions.toString(), Colors.orange)),
            const SizedBox(width: 16),
            Expanded(child: _buildStatCard('إجمالي المزايدات', totalBids.toString(), Colors.purple)),
          ],
        );
      },
    );
  }

  Widget _buildStatCard(String title, String value, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Icon(Icons.trending_up, color: color, size: 32),
            const SizedBox(height: 12),
            Text(
              value,
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(color: Colors.grey[600]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCommissionSection() {
    return StreamBuilder(
      stream: _firestore.collection('commissions').orderBy('createdAt', descending: true).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const CircularProgressIndicator();

        final commissions = snapshot.data!.docs;
        final totalEgp = commissions.fold<double>(0, (sum, c) => sum + (c['amount'] ?? 0));
        final totalJod = commissions.fold<double>(0, (sum, c) => sum + (c['jodAmount'] ?? 0));

        return Card(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'العمولات المحصلة',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.green[50],
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        '1% عمولة',
                        style: TextStyle(color: Colors.green[700]),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: _buildCommissionCard(
                        'إجمالي العمولات (EGP)',
                        '${NumberFormat('#,##0.00').format(totalEgp)} ج.م',
                        Colors.blue,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _buildCommissionCard(
                        'إجمالي العمولات (JOD)',
                        '${NumberFormat('#,##0.00').format(totalJod)} د.أ',
                        Colors.green,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Text(
                  'آخر العمولات',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 12),
                ListView.builder(
                  shrinkWrap: true,
                  itemCount: commissions.take(5).length,
                  itemBuilder: (context, index) {
                    final commission = commissions[index];
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.green[100],
                        child: Icon(Icons.attach_money, color: Colors.green[700]),
                      ),
                      title: Text('${NumberFormat('#,##0.00').format(commission['amount'])} ج.م'),
                      subtitle: Text(
                        DateFormat('yyyy/MM/dd HH:mm').format(commission['createdAt'].toDate()),
                      ),
                      trailing: Text(
                        '${NumberFormat('#,##0.00').format(commission['jodAmount'])} د.أ',
                        style: TextStyle(
                          color: Colors.green[700],
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCommissionCard(String title, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(color: Colors.grey[600])),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActiveAuctions() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'المزادات النشطة',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 16),
            StreamBuilder(
              stream: _firestore
                  .collection('auctions')
                  .where('isActive', isEqualTo: true)
                  .orderBy('endTime')
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const CircularProgressIndicator();

                final auctions = snapshot.data!.docs;

                return ListView.builder(
                  shrinkWrap: true,
                  itemCount: auctions.length,
                  itemBuilder: (context, index) {
                    final auction = auctions[index];
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: const Color(0xFF6B4EE6),
                        child: Text(auction['title'][0]),
                      ),
                      title: Text(auction['title']),
                      subtitle: Text('${auction['currentPrice']} ج.م - ${auction['bidCount']} مزايدات'),
                      trailing: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.green[50],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          'نشط',
                          style: TextStyle(color: Colors.green[700]),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUsersSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'المستخدمين',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 16),
            StreamBuilder(
              stream: _firestore.collection('users').orderBy('createdAt', descending: true).snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const CircularProgressIndicator();

                final users = snapshot.data!.docs;

                return ListView.builder(
                  shrinkWrap: true,
                  itemCount: users.take(10).length,
                  itemBuilder: (context, index) {
                    final user = users[index];
                    return ListTile(
                      leading: CircleAvatar(
                        child: Text(user['name'][0]),
                      ),
                      title: Text(user['name']),
                      subtitle: Text(user['phone'] ?? ''),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (user['isVerified'] == true)
                            Icon(Icons.verified, color: Colors.green[700]),
                          const SizedBox(width: 8),
                          Text('${user['auctionsCreated'] ?? 0} مزاد'),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
