class AppConstants {
  // App Info
  static const String appName = 'تطبيق مزاد';
  static const String appVersion = '1.0.0';

  // Currencies
  static const String clientCurrency = 'EGP'; // للعملاء في مصر
  static const String settlementCurrency = 'JOD'; // للتسوية في الأردن
  static const double egpToJodRate = 0.0228;

  // Commission
  static const double commissionPercentage = 0.01; // 1%

  // Paymob Configuration
  static const String paymobApiKey = 'YOUR_PAYMOB_API_KEY';
  static const String paymobIntegrationId = 'YOUR_INTEGRATION_ID';
  static const String paymobWalletIntegrationId = 'YOUR_WALLET_INTEGRATION_ID';
  static const String paymobIframeId = 'YOUR_IFRAME_ID';

  // Paymob Test Card
  static const String paymobTestCardNumber = '5123456789012346';
  static const String paymobTestExpiryMonth = '12';
  static const String paymobTestExpiryYear = '25';
  static const String paymobTestCvv = '123';

  // Paymob Test Wallet
  static const String paymobTestWalletNumber = '01010101010';
  static const String paymobTestWalletPin = '123456';
  static const String paymobTestWalletOtp = '123456';

  // Categories
  static const List<String> categories = [
    'سيارات',
    'عقارات',
    'إلكترونيات',
    'أثاث',
    'ملابس',
    'تحف',
    'أخرى',
  ];

  // Conditions
  static const List<String> conditions = ['جديد', 'مستعمل', 'مستعمل بحالة جيدة'];

  // Auction Durations
  static const Map<int, String> auctionDurations = {
    1: '1 ساعة',
    6: '6 ساعات',
    12: '12 ساعة',
    24: 'يوم واحد',
    48: 'يومين',
    72: '3 أيام',
    168: 'أسبوع',
  };

  // Payment Methods
  static const List<String> paymentMethods = [
    'بطاقة ائتمان',
    'فودافون كاش',
    'اتصالات كاش',
    'أورانج كاش',
    'فوري',
    'الدفع عند الاستلام',
  ];

  // Error Messages
  static const String errorNetwork = 'خطأ في الاتصال بالشبكة';
  static const String errorServer = 'خطأ في الخادم';
  static const String errorUnknown = 'حدث خطأ غير متوقع';
  static const String errorInvalidPhone = 'رقم الهاتف غير صحيح';
  static const String errorInvalidOTP = 'رمز التحقق غير صحيح';
  static const String errorBidTooLow = 'يجب أن تكون المزايدة أعلى من السعر الحالي';
  static const String errorAuctionEnded = 'انتهى المزاد';

  // Success Messages
  static const String successBidPlaced = 'تمت المزايدة بنجاح!';
  static const String successAuctionCreated = 'تم نشر المزاد بنجاح!';
  static const String successPayment = 'تم الدفع بنجاح!';
  static const String successLogin = 'تم تسجيل الدخول بنجاح!';
}
