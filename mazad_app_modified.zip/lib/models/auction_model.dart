import 'package:cloud_firestore/cloud_firestore.dart';

class Auction {
  final String id;
  final String title;
  final String description;
  final List<String> images;
  final double startPrice;
  double currentPrice;
  final String sellerId;
  final String sellerName;
  final String sellerPhone;
  String? winnerId;
  String? winnerName;
  final DateTime endTime;
  final DateTime createdAt;
  bool isActive;
  bool isPaid;
  final String category;
  final String condition; // جديد / مستعمل
  final String location;
  List<Bid> bids;
  int viewCount;
  int bidCount;

  // العملات
  static const String clientCurrency = 'EGP'; // للعملاء في مصر
  static const String settlementCurrency = 'JOD'; // للتسوية في الأردن
  static const double egpToJodRate = 0.0228; // سعر التحويل

  Auction({
    required this.id,
    required this.title,
    required this.description,
    required this.images,
    required this.startPrice,
    required this.currentPrice,
    required this.sellerId,
    required this.sellerName,
    required this.sellerPhone,
    this.winnerId,
    this.winnerName,
    required this.endTime,
    required this.createdAt,
    this.isActive = true,
    this.isPaid = false,
    required this.category,
    required this.condition,
    required this.location,
    this.bids = const [],
    this.viewCount = 0,
    this.bidCount = 0,
  });

  // ✅ العمولة 1% بالجنيه المصري
  double get commissionEgp => currentPrice * 0.01;

  // ✅ العمولة بالدينار الأردني (للتسوية)
  double get commissionJod => commissionEgp * egpToJodRate;

  // ✅ صافي البائع بالجنيه المصري
  double get sellerAmountEgp => currentPrice - commissionEgp;

  // ✅ صافي البائع بالدينار الأردني
  double get sellerAmountJod => sellerAmountEgp * egpToJodRate;

  // ✅ المبلغ الإجمالي للدفع (السعر + العمولة)
  double get totalAmount => currentPrice + commissionEgp;

  // ✅ الوقت المتبقي
  Duration get remainingTime => endTime.difference(DateTime.now());

  // ✅ هل المزاد منتهي؟
  bool get isExpired => DateTime.now().isAfter(endTime);

  // ✅ هل المزاد نشط؟
  bool get isLive => isActive && !isExpired;

  factory Auction.fromJson(Map<String, dynamic> json, String id) {
    return Auction(
      id: id,
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      images: List<String>.from(json['images'] ?? []),
      startPrice: (json['startPrice'] ?? 0).toDouble(),
      currentPrice: (json['currentPrice'] ?? 0).toDouble(),
      sellerId: json['sellerId'] ?? '',
      sellerName: json['sellerName'] ?? '',
      sellerPhone: json['sellerPhone'] ?? '',
      winnerId: json['winnerId'],
      winnerName: json['winnerName'],
      endTime: (json['endTime'] as Timestamp).toDate(),
      createdAt: (json['createdAt'] as Timestamp).toDate(),
      isActive: json['isActive'] ?? true,
      isPaid: json['isPaid'] ?? false,
      category: json['category'] ?? 'عام',
      condition: json['condition'] ?? 'مستعمل',
      location: json['location'] ?? '',
      bids: (json['bids'] as List<dynamic>? ?? [])
          .map((b) => Bid.fromJson(b))
          .toList(),
      viewCount: json['viewCount'] ?? 0,
      bidCount: json['bidCount'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'description': description,
      'images': images,
      'startPrice': startPrice,
      'currentPrice': currentPrice,
      'sellerId': sellerId,
      'sellerName': sellerName,
      'sellerPhone': sellerPhone,
      'winnerId': winnerId,
      'winnerName': winnerName,
      'endTime': Timestamp.fromDate(endTime),
      'createdAt': Timestamp.fromDate(createdAt),
      'isActive': isActive,
      'isPaid': isPaid,
      'category': category,
      'condition': condition,
      'location': location,
      'bids': bids.map((b) => b.toJson()).toList(),
      'viewCount': viewCount,
      'bidCount': bidCount,
    };
  }

  Auction copyWith({
    double? currentPrice,
    String? winnerId,
    String? winnerName,
    bool? isActive,
    bool? isPaid,
    List<Bid>? bids,
    int? viewCount,
    int? bidCount,
  }) {
    return Auction(
      id: id,
      title: title,
      description: description,
      images: images,
      startPrice: startPrice,
      currentPrice: currentPrice ?? this.currentPrice,
      sellerId: sellerId,
      sellerName: sellerName,
      sellerPhone: sellerPhone,
      winnerId: winnerId ?? this.winnerId,
      winnerName: winnerName ?? this.winnerName,
      endTime: endTime,
      createdAt: createdAt,
      isActive: isActive ?? this.isActive,
      isPaid: isPaid ?? this.isPaid,
      category: category,
      condition: condition,
      location: location,
      bids: bids ?? this.bids,
      viewCount: viewCount ?? this.viewCount,
      bidCount: bidCount ?? this.bidCount,
    );
  }
}

class Bid {
  final String userId;
  final String userName;
  final String userPhone;
  final double amount;
  final DateTime time;

  Bid({
    required this.userId,
    required this.userName,
    required this.userPhone,
    required this.amount,
    required this.time,
  });

  factory Bid.fromJson(Map<String, dynamic> json) {
    return Bid(
      userId: json['userId'] ?? '',
      userName: json['userName'] ?? '',
      userPhone: json['userPhone'] ?? '',
      amount: (json['amount'] ?? 0).toDouble(),
      time: (json['time'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'userName': userName,
      'userPhone': userPhone,
      'amount': amount,
      'time': Timestamp.fromDate(time),
    };
  }
}

class UserModel {
  final String id;
  final String name;
  final String phone;
  final String email;
  final String? imageUrl;
  final double balance;
  final int auctionsCreated;
  final int auctionsWon;
  final DateTime createdAt;
  final bool isVerified;
  final String? idNumber; // رقم البطاقة للتوثيق

  UserModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.email,
    this.imageUrl,
    this.balance = 0,
    this.auctionsCreated = 0,
    this.auctionsWon = 0,
    required this.createdAt,
    this.isVerified = false,
    this.idNumber,
  });

  factory UserModel.fromJson(Map<String, dynamic> json, String id) {
    return UserModel(
      id: id,
      name: json['name'] ?? '',
      phone: json['phone'] ?? '',
      email: json['email'] ?? '',
      imageUrl: json['imageUrl'],
      balance: (json['balance'] ?? 0).toDouble(),
      auctionsCreated: json['auctionsCreated'] ?? 0,
      auctionsWon: json['auctionsWon'] ?? 0,
      createdAt: (json['createdAt'] as Timestamp).toDate(),
      isVerified: json['isVerified'] ?? false,
      idNumber: json['idNumber'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'phone': phone,
      'email': email,
      'imageUrl': imageUrl,
      'balance': balance,
      'auctionsCreated': auctionsCreated,
      'auctionsWon': auctionsWon,
      'createdAt': Timestamp.fromDate(createdAt),
      'isVerified': isVerified,
      'idNumber': idNumber,
    };
  }
}

class Transaction {
  final String id;
  final String userId;
  final String auctionId;
  final double amount;
  final String type; // 'bid', 'commission', 'withdrawal', 'deposit'
  final String status; // 'pending', 'completed', 'failed'
  final DateTime createdAt;
  final String? paymentMethod;
  final String? transactionId; // من بوابة الدفع

  Transaction({
    required this.id,
    required this.userId,
    required this.auctionId,
    required this.amount,
    required this.type,
    required this.status,
    required this.createdAt,
    this.paymentMethod,
    this.transactionId,
  });

  factory Transaction.fromJson(Map<String, dynamic> json, String id) {
    return Transaction(
      id: id,
      userId: json['userId'] ?? '',
      auctionId: json['auctionId'] ?? '',
      amount: (json['amount'] ?? 0).toDouble(),
      type: json['type'] ?? '',
      status: json['status'] ?? 'pending',
      createdAt: (json['createdAt'] as Timestamp).toDate(),
      paymentMethod: json['paymentMethod'],
      transactionId: json['transactionId'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'auctionId': auctionId,
      'amount': amount,
      'type': type,
      'status': status,
      'createdAt': Timestamp.fromDate(createdAt),
      'paymentMethod': paymentMethod,
      'transactionId': transactionId,
    };
  }
}
