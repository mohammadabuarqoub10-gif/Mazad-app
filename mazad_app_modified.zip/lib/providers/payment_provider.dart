import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/auction_model.dart';

class PaymentProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  bool _isLoading = false;
  String? _error;
  List<Transaction> _transactions = [];
  double _totalCommissions = 0;

  bool get isLoading => _isLoading;
  String? get error => _error;
  List<Transaction> get transactions => _transactions;
  double get totalCommissions => _totalCommissions;

  // إنشاء عملية دفع للمزاد
  Future<bool> createPayment({
    required String auctionId,
    required double amount,
    required String paymentMethod, // 'card', 'wallet', 'fawry', 'cod'
  }) async {
    final user = _auth.currentUser;
    if (user == null) return false;

    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final transaction = Transaction(
        id: '',
        userId: user.uid,
        auctionId: auctionId,
        amount: amount,
        type: 'bid',
        status: 'pending',
        createdAt: DateTime.now(),
        paymentMethod: paymentMethod,
      );

      await _firestore.collection('transactions').add(transaction.toJson());

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // تأكيد الدفع وتحويل العمولة
  Future<bool> confirmPayment(String transactionId) async {
    try {
      await _firestore.runTransaction((transaction) async {
        final transRef = _firestore.collection('transactions').doc(transactionId);
        final transSnap = await transaction.get(transRef);

        if (!transSnap.exists) throw Exception('العملية غير موجودة');

        final transData = transSnap.data()!;
        final auctionId = transData['auctionId'];
        final amount = (transData['amount'] ?? 0).toDouble();

        // تحديث حالة العملية
        transaction.update(transRef, {'status': 'completed'});

        // تحديث المزاد
        final auctionRef = _firestore.collection('auctions').doc(auctionId);
        transaction.update(auctionRef, {'isPaid': true});

        // تسجيل العمولة (1%)
        final commission = amount * 0.01;
        transaction.set(
          _firestore.collection('commissions').doc(),
          {
            'transactionId': transactionId,
            'auctionId': auctionId,
            'amount': commission,
            'currency': 'EGP',
            'jodAmount': commission * 0.0228, // تحويل لـ JOD
            'percentage': 1,
            'status': 'collected',
            'createdAt': Timestamp.now(),
          },
        );
      });

      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }

  // جلب العمولات المحصلة
  Future<void> loadCommissions() async {
    _isLoading = true;
    notifyListeners();

    try {
      final snapshot = await _firestore
          .collection('commissions')
          .orderBy('createdAt', descending: true)
          .get();

      double total = 0;
      for (var doc in snapshot.docs) {
        total += (doc.data()['amount'] ?? 0).toDouble();
      }

      _totalCommissions = total;
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // جلب معاملات المستخدم
  Future<void> loadUserTransactions() async {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return;

    _isLoading = true;
    notifyListeners();

    try {
      final snapshot = await _firestore
          .collection('transactions')
          .where('userId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();

      _transactions = snapshot.docs
          .map((doc) => Transaction.fromJson(doc.data(), doc.id))
          .toList();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // حساب إجمالي العمولات للتسوية
  Future<Map<String, double>> getSettlementSummary() async {
    try {
      final snapshot = await _firestore
          .collection('commissions')
          .where('status', isEqualTo: 'collected')
          .get();

      double totalEgp = 0;
      double totalJod = 0;

      for (var doc in snapshot.docs) {
        final data = doc.data();
        totalEgp += (data['amount'] ?? 0).toDouble();
        totalJod += (data['jodAmount'] ?? 0).toDouble();
      }

      return {
        'totalEgp': totalEgp,
        'totalJod': totalJod,
      };
    } catch (e) {
      _error = e.toString();
      return {'totalEgp': 0, 'totalJod': 0};
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
