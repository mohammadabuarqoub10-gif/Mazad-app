import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/auction_model.dart';

class AuthProvider extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? _user;
  UserModel? _userModel;
  bool _isLoading = false;
  String? _error;

  User? get user => _user;
  UserModel? get userModel => _userModel;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isLoggedIn => _user != null || _userModel != null;

  AuthProvider() {
    _auth.authStateChanges().listen((user) async {
      _user = user;
      if (user != null) {
        await _loadUserData(user.uid);
      } else {
        _userModel = null;
      }
      notifyListeners();
    });
  }

  Future<void> _loadUserData(String uid) async {
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      if (doc.exists) {
        _userModel = UserModel.fromJson(doc.data()!, doc.id);
      }
    } catch (e) {
      _error = e.toString();
    }
  }

  /// ✅ تسجيل دخول بسيط جداً - بدون OTP وبدون Firebase Auth
  Future<void> simpleLogin({
    required String name,
    required String phone,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // إنشاء معرف فريد من رقم الهاتف
      final userId = 'user_${phone.replaceAll(RegExp(r'[^0-9]'), '')}';

      // التحقق إذا كان المستخدم موجوداً
      final userDoc = await _firestore.collection('users').doc(userId).get();

      if (userDoc.exists) {
        // المستخدم موجود - تحديث آخر دخول
        await _firestore.collection('users').doc(userId).update({
          'lastLogin': FieldValue.serverTimestamp(),
        });

        _userModel = UserModel.fromJson(userDoc.data()!, userId);
      } else {
        // مستخدم جديد - إنشاء حساب
        final userData = UserModel(
          id: userId,
          name: name,
          phone: phone,
          email: '',
          createdAt: DateTime.now(),
        );

        await _firestore.collection('users').doc(userId).set({
          ...userData.toJson(),
          'lastLogin': FieldValue.serverTimestamp(),
        });

        _userModel = userData;
      }

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = 'حدث خطأ: $e';
      _isLoading = false;
      notifyListeners();
    }
  }

  /// تسجيل الدخول بالهاتف (OTP) - للمستخدمين المتقدمين
  Future<void> signInWithPhone(String phoneNumber, Function(String) onCodeSent) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      await _auth.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        verificationCompleted: (PhoneAuthCredential credential) async {
          await _auth.signInWithCredential(credential);
        },
        verificationFailed: (FirebaseAuthException e) {
          _error = e.message;
          _isLoading = false;
          notifyListeners();
        },
        codeSent: (String verificationId, int? resendToken) {
          onCodeSent(verificationId);
          _isLoading = false;
          notifyListeners();
        },
        codeAutoRetrievalTimeout: (String verificationId) {},
      );
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  /// التحقق من رمز OTP
  Future<bool> verifyOTP(String verificationId, String smsCode) async {
    _isLoading = true;
    notifyListeners();

    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId,
        smsCode: smsCode,
      );

      final userCredential = await _auth.signInWithCredential(credential);
      _user = userCredential.user;

      if (userCredential.additionalUserInfo?.isNewUser ?? false) {
        await _createUserDocument();
      }

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = 'رمز التحقق غير صحيح';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> _createUserDocument() async {
    if (_user == null) return;

    final userData = UserModel(
      id: _user!.uid,
      name: _user!.displayName ?? 'مستخدم جديد',
      phone: _user!.phoneNumber ?? '',
      email: _user!.email ?? '',
      createdAt: DateTime.now(),
    );

    await _firestore.collection('users').doc(_user!.uid).set(userData.toJson());
    _userModel = userData;
  }

  /// تسجيل الخروج
  Future<void> signOut() async {
    await _auth.signOut();
    _user = null;
    _userModel = null;
    notifyListeners();
  }

  /// تحديث البيانات
  Future<void> updateProfile({String? name, String? email, String? idNumber}) async {
    if (_user == null && _userModel == null) return;

    final userId = _user?.uid ?? _userModel?.id;
    if (userId == null) return;

    final updates = <String, dynamic>{};
    if (name != null) updates['name'] = name;
    if (email != null) updates['email'] = email;
    if (idNumber != null) {
      updates['idNumber'] = idNumber;
      updates['isVerified'] = true;
    }

    await _firestore.collection('users').doc(userId).update(updates);
    await _loadUserData(userId);
    notifyListeners();
  }
}
