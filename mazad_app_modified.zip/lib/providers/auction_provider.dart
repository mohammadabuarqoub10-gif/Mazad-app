import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/auction_model.dart';

class AuctionProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  List<Auction> _auctions = [];
  List<Auction> _myAuctions = [];
  List<Auction> _myBids = [];
  bool _isLoading = false;
  String? _error;
  Auction? _selectedAuction;

  List<Auction> get auctions => _auctions;
  List<Auction> get myAuctions => _myAuctions;
  List<Auction> get myBids => _myBids;
  bool get isLoading => _isLoading;
  String? get error => _error;
  Auction? get selectedAuction => _selectedAuction;

  // جلب المزادات النشطة
  Stream<List<Auction>> getActiveAuctionsStream() {
    return _firestore
        .collection('auctions')
        .where('isActive', isEqualTo: true)
        .where('endTime', isGreaterThan: Timestamp.now())
        .orderBy('endTime', descending: false)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Auction.fromJson(doc.data(), doc.id))
            .toList());
  }

  // جلب المزادات حسب الفئة
  Stream<List<Auction>> getAuctionsByCategory(String category) {
    return _firestore
        .collection('auctions')
        .where('category', isEqualTo: category)
        .where('isActive', isEqualTo: true)
        .orderBy('endTime')
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Auction.fromJson(doc.data(), doc.id))
            .toList());
  }

  // جلب مزاداتي (المنشورة)
  Future<void> loadMyAuctions() async {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return;

    _isLoading = true;
    notifyListeners();

    try {
      final snapshot = await _firestore
          .collection('auctions')
          .where('sellerId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();

      _myAuctions = snapshot.docs
          .map((doc) => Auction.fromJson(doc.data(), doc.id))
          .toList();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // جلب المزادات التي شاركت فيها
  Future<void> loadMyBids() async {
    final userId = _auth.currentUser?.uid;
    if (userId == null) return;

    _isLoading = true;
    notifyListeners();

    try {
      final snapshot = await _firestore
          .collection('auctions')
          .where('bids', arrayContains: {'userId': userId})
          .get();

      _myBids = snapshot.docs
          .map((doc) => Auction.fromJson(doc.data(), doc.id))
          .toList();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // إنشاء مزاد جديد
  Future<bool> createAuction({
    required String title,
    required String description,
    required List<String> images,
    required double startPrice,
    required DateTime endTime,
    required String category,
    required String condition,
    required String location,
  }) async {
    final user = _auth.currentUser;
    if (user == null) {
      _error = 'يجب تسجيل الدخول أولاً';
      notifyListeners();
      return false;
    }

    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // جلب بيانات المستخدم
      final userDoc = await _firestore.collection('users').doc(user.uid).get();
      final userData = userDoc.data();

      final auction = Auction(
        id: '',
        title: title,
        description: description,
        images: images,
        startPrice: startPrice,
        currentPrice: startPrice,
        sellerId: user.uid,
        sellerName: userData?['name'] ?? 'مستخدم',
        sellerPhone: userData?['phone'] ?? '',
        endTime: endTime,
        createdAt: DateTime.now(),
        category: category,
        condition: condition,
        location: location,
      );

      await _firestore.collection('auctions').add(auction.toJson());

      // تحديث إحصائيات المستخدم
      await _firestore.collection('users').doc(user.uid).update({
        'auctionsCreated': FieldValue.increment(1),
      });

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = 'فشل إنشاء المزاد: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // المزايدة على مزاد
  Future<bool> placeBid(String auctionId, double amount) async {
    final user = _auth.currentUser;
    if (user == null) {
      _error = 'يجب تسجيل الدخول أولاً';
      notifyListeners();
      return false;
    }

    try {
      final userDoc = await _firestore.collection('users').doc(user.uid).get();
      final userData = userDoc.data();

      final bid = Bid(
        userId: user.uid,
        userName: userData?['name'] ?? 'مستخدم',
        userPhone: userData?['phone'] ?? '',
        amount: amount,
        time: DateTime.now(),
      );

      await _firestore.runTransaction((transaction) async {
        final docRef = _firestore.collection('auctions').doc(auctionId);
        final snapshot = await transaction.get(docRef);

        if (!snapshot.exists) throw Exception('المزاد غير موجود');

        final data = snapshot.data()!;
        final currentPrice = (data['currentPrice'] ?? 0).toDouble();
        final endTime = (data['endTime'] as Timestamp).toDate();

        if (DateTime.now().isAfter(endTime)) {
          throw Exception('انتهى المزاد');
        }

        if (amount <= currentPrice) {
          throw Exception('يجب أن تكون المزايدة أعلى من السعر الحالي');
        }

        transaction.update(docRef, {
          'currentPrice': amount,
          'winnerId': user.uid,
          'winnerName': bid.userName,
          'bids': FieldValue.arrayUnion([bid.toJson()]),
          'bidCount': FieldValue.increment(1),
        });
      });

      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }

  // إنهاء المزاد وتحصيل العمولة
  Future<bool> finalizeAuction(String auctionId) async {
    try {
      await _firestore.runTransaction((transaction) async {
        final docRef = _firestore.collection('auctions').doc(auctionId);
        final snapshot = await transaction.get(docRef);

        if (!snapshot.exists) throw Exception('المزاد غير موجود');

        final data = snapshot.data()!;
        final endTime = (data['endTime'] as Timestamp).toDate();
        final winnerId = data['winnerId'];

        if (DateTime.now().isBefore(endTime)) {
          throw Exception('لم ينتهِ المزاد بعد');
        }

        if (winnerId == null) {
          throw Exception('لا يوجد فائز');
        }

        final currentPrice = (data['currentPrice'] ?? 0).toDouble();
        final commission = currentPrice * 0.01; // 1% عمولة

        transaction.update(docRef, {
          'isActive': false,
          'commission': commission,
          'sellerAmount': currentPrice - commission,
        });

        // تسجيل العمولة
        transaction.set(
          _firestore.collection('commissions').doc(),
          {
            'auctionId': auctionId,
            'amount': commission,
            'currency': 'EGP',
            'jodAmount': commission * 0.0228,
            'percentage': 1,
            'createdAt': Timestamp.now(),
          },
        );
      });

      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }

  // زيادة عدد المشاهدات
  Future<void> incrementViewCount(String auctionId) async {
    await _firestore.collection('auctions').doc(auctionId).update({
      'viewCount': FieldValue.increment(1),
    });
  }

  void selectAuction(Auction auction) {
    _selectedAuction = auction;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
