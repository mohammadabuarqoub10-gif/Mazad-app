# API Documentation - تطبيق مزاد

## Base URL
```
https://your-firebase-project.cloudfunctions.net/api
```

## Authentication
All endpoints require Firebase Authentication token in the header:
```
Authorization: Bearer <FIREBASE_ID_TOKEN>
```

## Endpoints

### 1. Auctions

#### Get All Auctions
```http
GET /auctions
```

**Query Parameters:**
- `category` (optional): Filter by category
- `status` (optional): `active` or `ended`
- `limit` (optional): Number of results (default: 20)
- `offset` (optional): Pagination offset

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "auction_123",
      "title": "iPhone 14 Pro",
      "description": "...",
      "currentPrice": 25000,
      "startPrice": 20000,
      "endTime": "2024-01-15T12:00:00Z",
      "isActive": true,
      "sellerId": "user_123",
      "sellerName": "Ahmed",
      "category": "إلكترونيات",
      "condition": "جديد",
      "bidCount": 5,
      "viewCount": 120,
      "commission": 250,
      "sellerAmount": 24750
    }
  ],
  "total": 100
}
```

#### Create Auction
```http
POST /auctions
```

**Request Body:**
```json
{
  "title": "iPhone 14 Pro",
  "description": "...",
  "startPrice": 20000,
  "duration": 24,
  "category": "إلكترونيات",
  "condition": "جديد",
  "location": "القاهرة",
  "images": ["url1", "url2"]
}
```

#### Place Bid
```http
POST /auctions/{auctionId}/bid
```

**Request Body:**
```json
{
  "amount": 25000
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "bidId": "bid_123",
    "amount": 25000,
    "timestamp": "2024-01-10T12:00:00Z",
    "newPrice": 25000
  }
}
```

### 2. Users

#### Get User Profile
```http
GET /users/{userId}
```

#### Update Profile
```http
PUT /users/{userId}
```

**Request Body:**
```json
{
  "name": "Ahmed Mohamed",
  "email": "ahmed@example.com",
  "idNumber": "12345678901234"
}
```

### 3. Payments

#### Create Payment
```http
POST /payments
```

**Request Body:**
```json
{
  "auctionId": "auction_123",
  "amount": 25000,
  "paymentMethod": "card"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "paymentKey": "pay_key_123",
    "orderId": "order_123",
    "paymentUrl": "https://accept.paymob.com/..."
  }
}
```

#### Verify Payment
```http
POST /payments/verify
```

**Request Body:**
```json
{
  "orderId": "order_123",
  "transactionId": "txn_123"
}
```

### 4. Notifications

#### Get Notifications
```http
GET /notifications
```

#### Mark as Read
```http
PUT /notifications/{notificationId}/read
```

## Error Responses

```json
{
  "success": false,
  "error": {
    "code": "INVALID_BID",
    "message": "يجب أن تكون المزايدة أعلى من السعر الحالي",
    "details": {
      "currentPrice": 25000,
      "yourBid": 24000
    }
  }
}
```

## Error Codes

| Code | Description |
|------|-------------|
| `UNAUTHORIZED` | المستخدم غير مسجل |
| `INVALID_BID` | مزايدة غير صالحة |
| `AUCTION_ENDED` | المزاد منتهي |
| `INSUFFICIENT_FUNDS` | رصيد غير كافي |
| `PAYMENT_FAILED` | فشل الدفع |
| `INVALID_INPUT` | بيانات غير صالحة |

## Webhooks

### Payment Callback
```http
POST /webhooks/paymob
```

**Payload:**
```json
{
  "order": 123,
  "id": "txn_123",
  "success": true,
  "amount_cents": 2500000,
  "currency": "EGP"
}
```

## Rate Limiting

- 100 requests per minute for authenticated users
- 20 requests per minute for unauthenticated users

## SDKs

### Flutter
```dart
import 'package:mazad_api/mazad_api.dart';

final api = MazadApi(apiKey: 'your_api_key');
final auctions = await api.auctions.getAll();
```

### Node.js
```javascript
const Mazad = require('mazad-api');
const client = new Mazad('your_api_key');
const auctions = await client.auctions.list();
```
