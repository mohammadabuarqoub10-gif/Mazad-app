# دليل النشر - تطبيق مزاد

## متطلبات النظام

### التطوير
- Flutter SDK >= 3.0.0
- Dart SDK >= 3.0.0
- Android Studio / Xcode
- Firebase CLI
- Node.js >= 18 (لـ Cloud Functions)

### الإنتاج
- حساب Firebase
- حساب Paymob (للمدفوعات)
- حساب Google Play Console (لـ Android)
- حساب Apple Developer (لـ iOS)
- حساب Wise / بنك أردني (للتسوية)

## خطوات النشر

### 1. إعداد Firebase

```bash
# تثبيت Firebase CLI
npm install -g firebase-tools

# تسجيل الدخول
firebase login

# تهيئة المشروع
firebase init

# اختر:
# - Firestore
# - Functions
# - Storage
# - Hosting (لـ Admin Dashboard)
```

### 2. إعداد Paymob

1. سجّل في [Paymob](https://paymob.com)
2. أكمل التحقق من الهوية
3. احصل على API Keys:
   - API Key
   - Integration ID
   - IFrame ID
4. أضف Webhook URL:
   ```
   https://your-app.com/webhooks/paymob
   ```

### 3. بناء التطبيق

#### Android
```bash
# توليد ملف APK
flutter build apk --release

# توليد ملف AAB (لـ Google Play)
flutter build appbundle --release
```

#### iOS
```bash
# توليد ملف IPA
flutter build ios --release

# فتح Xcode
open ios/Runner.xcworkspace

# Build & Archive
# Product > Archive
```

### 4. نشر Cloud Functions

```bash
cd firebase/functions

# تثبيت الاعتماديات
npm install

# النشر
firebase deploy --only functions
```

### 5. نشر Admin Dashboard

```bash
# بناء Dashboard
flutter build web --release

# النشر على Firebase Hosting
firebase deploy --only hosting
```

### 6. نشر التطبيق على المتاجر

#### Google Play Store
1. سجّل في [Google Play Console](https://play.google.com/console)
2. أنشئ تطبيق جديد
3. ارفع ملف AAB
4. أضف صور ولقطات شاشة
5. املأ معلومات التطبيق
6. أرسل للمراجعة

#### Apple App Store
1. سجّل في [Apple Developer](https://developer.apple.com)
2. أنشئ App ID
3. ارفع التطبيق عبر Xcode
4. أضف صور ولقطات شاشة
5. املأ معلومات التطبيق
6. أرسل للمراجعة

## التكوين

### Firebase Config
```json
{
  "apiKey": "YOUR_API_KEY",
  "authDomain": "your-project.firebaseapp.com",
  "projectId": "your-project",
  "storageBucket": "your-project.appspot.com",
  "messagingSenderId": "123456789",
  "appId": "1:123456789:web:abcdef"
}
```

### Paymob Config
```dart
const String paymobApiKey = 'YOUR_API_KEY';
const String paymobIntegrationId = 'YOUR_INTEGRATION_ID';
const String paymobIframeId = 'YOUR_IFRAME_ID';
```

## الأمان

### 1. Firebase Security Rules
- تحقق من قواعد Firestore
- تحقق من قواعد Storage
- فعّل App Check

### 2. SSL/TLS
- استخدم HTTPS فقط
- فعّل HSTS
- استخدم Certificate Pinning

### 3. البيانات
- تشفير البيانات الحساسة
- لا تخزن بيانات البطاقات
- استخدم Firebase Authentication

## المراقبة

### Firebase Analytics
```bash
firebase analytics:export
```

### Crashlytics
```bash
firebase crashlytics:symbols:upload
```

### Performance Monitoring
```bash
firebase performance:traces:list
```

## التحديثات

### إصدار جديد
1. تحديث رقم الإصدار في `pubspec.yaml`
2. تحديث CHANGELOG.md
3. بناء واختبار
4. النشر على المتاجر

### Cloud Functions
```bash
firebase deploy --only functions
```

## الدعم

- البريد: support@mazad.app
- الهاتف: +962 7X XXX XXXX
- الوثائق: https://docs.mazad.app
