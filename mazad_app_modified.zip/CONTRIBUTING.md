# Contributing to تطبيق مزاد

## كيفية المساهمة

### الإبلاغ عن مشاكل
1. تحقق من عدم وجود Issue مفتوح لنفس المشكلة
2. افتح Issue جديد مع:
   - وصف واضح للمشكلة
   - خطوات إعادة الإنتاج
   - لقطات شاشة (إن وجدت)
   - معلومات الجهاز (Flutter version, OS)

### اقتراح ميزات
1. افتح Issue مع وسم `feature-request`
2. وصف الميزة والفائدة المتوقعة
3. أمثلة على الاستخدام

### Pull Requests
1. Fork المستودع
2. أنشئ فرعاً جديداً (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push إلى الفرع (`git push origin feature/amazing-feature`)
5. افتح Pull Request

### معايير الكود
- اتباع style guide Flutter
- استخدام `flutter analyze` قبل الـ commit
- كتابة tests للميزات الجديدة
- تحديث التوثيق

## قواعد الـ Commit

```
feat: إضافة ميزة جديدة
fix: إصلاح مشكلة
docs: تحديث التوثيق
style: تغييرات formatting
refactor: إعادة هيكلة الكود
test: إضافة/تحديث tests
chore: تحديث dependencies
```

## شكراً! 🙏

نشكر كل من ساهم في تطوير هذا المشروع:
- [اسم المساهم]
- [اسم المساهم]
