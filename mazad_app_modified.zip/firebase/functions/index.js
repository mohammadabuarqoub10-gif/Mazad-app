const functions = require('firebase-functions');
const admin = require('firebase-admin');

admin.initializeApp();

// إشعار عند إنشاء مزاد جديد
exports.onAuctionCreated = functions.firestore
  .document('auctions/{auctionId}')
  .onCreate(async (snap, context) => {
    const auction = snap.data();

    const message = {
      notification: {
        title: 'مزاد جديد!',
        body: `تم نشر مزاد جديد: ${auction.title}`,
      },
      data: {
        auctionId: context.params.auctionId,
        type: 'new_auction',
      },
      topic: 'new_auctions',
    };

    await admin.messaging().send(message);
  });

// إشعار عند المزايدة
exports.onBidPlaced = functions.firestore
  .document('auctions/{auctionId}')
  .onUpdate(async (change, context) => {
    const newData = change.after.data();
    const oldData = change.before.data();

    if (newData.currentPrice > oldData.currentPrice) {
      const sellerMessage = {
        notification: {
          title: 'مزايدة جديدة!',
          body: `تمت مزايدة جديدة على ${newData.title}: ${newData.currentPrice} ج.م`,
        },
        data: {
          auctionId: context.params.auctionId,
          type: 'new_bid',
        },
        token: newData.sellerToken,
      };

      await admin.messaging().send(sellerMessage);
    }
  });

// إشعار عند انتهاء المزاد + تحويل العمولة التلقائي
exports.onAuctionEnded = functions.pubsub
  .schedule('every 1 minutes')
  .onRun(async (context) => {
    const now = admin.firestore.Timestamp.now();

    const expiredAuctions = await admin.firestore()
      .collection('auctions')
      .where('endTime', '<=', now)
      .where('isActive', '==', true)
      .get();

    const batch = admin.firestore().batch();

    for (const doc of expiredAuctions.docs) {
      const auction = doc.data();

      // إنهاء المزاد
      batch.update(doc.ref, {
        isActive: false,
        finalPrice: auction.currentPrice,
        commission: auction.currentPrice * 0.01,
        sellerAmount: auction.currentPrice * 0.99,
      });

      // حساب العمولة وتحويلها
      const commissionEgp = auction.currentPrice * 0.01;
      const exchangeRate = 0.0133; // EGP to JOD
      const commissionJod = commissionEgp * exchangeRate;

      // تسجيل العمولة
      const commissionRef = admin.firestore().collection('commissions').doc();
      batch.set(commissionRef, {
        auctionId: doc.id,
        amount: commissionEgp,
        currency: 'EGP',
        jodAmount: commissionJod,
        exchangeRate: exchangeRate,
        percentage: 1,
        status: 'collected',
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      // التحقق من إعدادات التحويل التلقائي
      const sellerDoc = await admin.firestore()
        .collection('users')
        .doc(auction.sellerId)
        .get();

      if (sellerDoc.exists) {
        const sellerData = sellerDoc.data();

        // إذا كان التحويل التلقائي مفعلاً
        if (sellerData.autoTransfer === true) {
          // إنشاء طلب تحويل بنكي
          const transferRef = admin.firestore().collection('bankTransfers').doc();
          batch.set(transferRef, {
            userId: auction.sellerId,
            commissionId: commissionRef.id,
            auctionId: doc.id,
            egpAmount: commissionEgp,
            jodAmount: commissionJod,
            exchangeRate: exchangeRate,
            fees: commissionEgp * 0.005, // 0.5% رسوم Wise
            netAmount: commissionEgp * 0.995,
            status: 'pending',
            bankAccount: sellerData.bankAccount || null,
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
          });

          // إشعار للبائع
          await admin.messaging().send({
            notification: {
              title: 'تم بيع منتجك!',
              body: `تم بيع ${auction.title} بسعر ${auction.currentPrice} ج.م. العمولة: ${commissionEgp} ج.م (${commissionJod.toFixed(2)} د.أ)`,
            },
            data: {
              auctionId: doc.id,
              type: 'auction_sold',
              commission: commissionEgp.toString(),
              jodAmount: commissionJod.toString(),
            },
            token: sellerData.fcmToken,
          });
        }

        // إشعار للفائز
        if (auction.winnerId) {
          const winnerDoc = await admin.firestore()
            .collection('users')
            .doc(auction.winnerId)
            .get();

          if (winnerDoc.exists) {
            const winnerData = winnerDoc.data();

            await admin.messaging().send({
              notification: {
                title: 'تهانينا! لقد فزت بالمزاد',
                body: `لقد فزت بمزاد: ${auction.title} بسعر ${auction.currentPrice} ج.م`,
              },
              data: {
                auctionId: doc.id,
                type: 'auction_won',
              },
              token: winnerData.fcmToken,
            });
          }
        }
      }
    }

    await batch.commit();
  });

// معالجة التحويلات البنكية المعلقة (تشغيل يومي)
exports.processBankTransfers = functions.pubsub
  .schedule('0 9 * * *') // كل يوم الساعة 9 صباحاً
  .onRun(async (context) => {
    const pendingTransfers = await admin.firestore()
      .collection('bankTransfers')
      .where('status', '==', 'pending')
      .get();

    for (const doc of pendingTransfers.docs) {
      const transfer = doc.data();

      // TODO: استدعاء API Wise لإنشاء التحويل
      // const wiseTransfer = await createWiseTransfer({
      //   amount: transfer.jodAmount,
      //   recipient: transfer.bankAccount,
      // });

      // تحديث حالة التحويل
      await doc.ref.update({
        status: 'processing',
        processedAt: admin.firestore.FieldValue.serverTimestamp(),
        // wiseTransferId: wiseTransfer.id,
      });

      // إشعار للمستخدم
      const userDoc = await admin.firestore()
        .collection('users')
        .doc(transfer.userId)
        .get();

      if (userDoc.exists) {
        const userData = userDoc.data();

        await admin.messaging().send({
          notification: {
            title: 'تحويل بنكي قيد المعالجة',
            body: `تم إرسال ${transfer.jodAmount.toFixed(2)} د.أ إلى حسابك البنكي`,
          },
          data: {
            transferId: doc.id,
            type: 'bank_transfer_processing',
          },
          token: userData.fcmToken,
        });
      }
    }
  });

// تحديث سعر الصرف (كل 6 ساعات)
exports.updateExchangeRate = functions.pubsub
  .schedule('0 */6 * * *')
  .onRun(async (context) => {
    // TODO: جلب سعر الصرف من API
    // const rate = await fetchExchangeRate('EGP', 'JOD');

    await admin.firestore().collection('exchangeRates').doc('EGP_JOD').set({
      rate: 0.0133, // سعر محدث
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      source: 'currency_api',
    });
  });

// إشعار الدفع
exports.onPaymentReceived = functions.firestore
  .document('transactions/{transactionId}')
  .onUpdate(async (change, context) => {
    const newData = change.after.data();
    const oldData = change.before.data();

    if (newData.status === 'completed' && oldData.status !== 'completed') {
      const userDoc = await admin.firestore()
        .collection('users')
        .doc(newData.userId)
        .get();

      if (userDoc.exists) {
        const userData = userDoc.data();

        await admin.messaging().send({
          notification: {
            title: 'تم استلام الدفع',
            body: `تم استلام دفع ${newData.amount} ج.م بنجاح`,
          },
          data: {
            transactionId: context.params.transactionId,
            type: 'payment_received',
          },
          token: userData.fcmToken,
        });
      }
    }
  });
