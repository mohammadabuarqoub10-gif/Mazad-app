const functions = require('firebase-functions');
const admin = require('firebase-admin');
const axios = require('axios');

admin.initializeApp();
const db = admin.firestore();

// ========================
// إشعار عند إنشاء مزاد جديد
// ========================
exports.onAuctionCreated = functions.firestore
  .document('auctions/{auctionId}')
  .onCreate(async (snap, context) => {
    const auction = snap.data();
    try {
      await admin.messaging().send({
        notification: {
          title: 'مزاد جديد!',
          body: `تم نشر مزاد جديد: ${auction.title}`,
        },
        data: { auctionId: context.params.auctionId, type: 'new_auction' },
        topic: 'new_auctions',
      });
    } catch (e) {
      console.error('onAuctionCreated notification error:', e);
    }
  });

// ========================
// إشعار عند المزايدة
// ========================
exports.onBidPlaced = functions.firestore
  .document('auctions/{auctionId}')
  .onUpdate(async (change, context) => {
    const newData = change.after.data();
    const oldData = change.before.data();

    if (newData.currentPrice <= oldData.currentPrice) return;

    // إشعار للبائع
    if (newData.sellerToken) {
      try {
        await admin.messaging().send({
          notification: {
            title: 'مزايدة جديدة!',
            body: `مزايدة جديدة على ${newData.title}: ${newData.currentPrice} ج.م`,
          },
          data: { auctionId: context.params.auctionId, type: 'new_bid' },
          token: newData.sellerToken,
        });
      } catch (e) {
        console.error('onBidPlaced notification error:', e);
      }
    }

    // تسجيل إشعار في Firestore للبائع
    await db.collection('notifications').add({
      userId: newData.sellerId,
      title: 'مزايدة جديدة!',
      body: `مزايدة جديدة على ${newData.title}: ${newData.currentPrice} ج.م`,
      type: 'new_bid',
      auctionId: context.params.auctionId,
      isRead: false,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  });

// ========================
// إنهاء المزادات المنتهية (كل دقيقة)
// ========================
exports.onAuctionEnded = functions.pubsub
  .schedule('every 1 minutes')
  .onRun(async (context) => {
    const now = admin.firestore.Timestamp.now();

    const expiredAuctions = await db.collection('auctions')
      .where('endTime', '<=', now)
      .where('isActive', '==', true)
      .get();

    if (expiredAuctions.empty) return;

    const batch = db.batch();

    for (const doc of expiredAuctions.docs) {
      const auction = doc.data();
      const commissionEgp = auction.currentPrice * 0.01;

      // جلب سعر الصرف الحالي
      const rateDoc = await db.collection('exchangeRates').doc('EGP_JOD').get();
      const exchangeRate = rateDoc.exists ? rateDoc.data().rate : 0.0133;
      const commissionJod = commissionEgp * exchangeRate;

      // إنهاء المزاد
      batch.update(doc.ref, {
        isActive: false,
        finalPrice: auction.currentPrice,
        commission: commissionEgp,
        sellerAmount: auction.currentPrice * 0.99,
        endedAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      // تسجيل العمولة
      const commissionRef = db.collection('commissions').doc();
      batch.set(commissionRef, {
        auctionId: doc.id,
        amount: commissionEgp,
        currency: 'EGP',
        jodAmount: commissionJod,
        exchangeRate,
        percentage: 1,
        status: 'collected',
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      // جلب بيانات البائع
      const sellerDoc = await db.collection('users').doc(auction.sellerId).get();
      if (sellerDoc.exists) {
        const sellerData = sellerDoc.data();

        // إشعار للبائع
        await db.collection('notifications').add({
          userId: auction.sellerId,
          title: 'تم بيع منتجك!',
          body: `بيع ${auction.title} بسعر ${auction.currentPrice} ج.م. العمولة: ${commissionEgp.toFixed(2)} ج.م`,
          type: 'auction_sold',
          auctionId: doc.id,
          isRead: false,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        // إنشاء طلب تحويل بنكي إذا كان التحويل التلقائي مفعلاً
        if (sellerData.autoTransfer === true && sellerData.bankAccount) {
          const transferRef = db.collection('bankTransfers').doc();
          batch.set(transferRef, {
            userId: auction.sellerId,
            commissionId: commissionRef.id,
            auctionId: doc.id,
            egpAmount: commissionEgp,
            jodAmount: commissionJod,
            exchangeRate,
            fees: commissionEgp * 0.005,
            netAmount: commissionEgp * 0.995,
            status: 'pending',
            bankAccount: sellerData.bankAccount,
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
          });
        }

        // إشعار للفائز
        if (auction.winnerId) {
          await db.collection('notifications').add({
            userId: auction.winnerId,
            title: 'تهانينا! فزت بالمزاد',
            body: `فزت بمزاد: ${auction.title} بسعر ${auction.currentPrice} ج.م`,
            type: 'auction_won',
            auctionId: doc.id,
            isRead: false,
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
          });
        }
      }
    }

    await batch.commit();
    console.log(`Finalized ${expiredAuctions.size} auctions.`);
  });

// ========================
// معالجة التحويلات البنكية المعلقة (يومياً الساعة 9 صباحاً)
// ========================
exports.processBankTransfers = functions.pubsub
  .schedule('0 9 * * *')
  .onRun(async (context) => {
    const pendingTransfers = await db.collection('bankTransfers')
      .where('status', '==', 'pending')
      .get();

    for (const doc of pendingTransfers.docs) {
      const transfer = doc.data();

      try {
        // استدعاء Wise API للتحويل الفعلي
        // const wiseApiKey = functions.config().wise.api_key;
        // const wiseResponse = await axios.post('https://api.wise.com/v1/transfers', {
        //   ...
        // }, { headers: { Authorization: `Bearer ${wiseApiKey}` } });

        await doc.ref.update({
          status: 'processing',
          processedAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        // إشعار للمستخدم
        await db.collection('notifications').add({
          userId: transfer.userId,
          title: 'تحويل بنكي قيد المعالجة',
          body: `تم إرسال ${transfer.jodAmount.toFixed(2)} د.أ إلى حسابك البنكي`,
          type: 'bank_transfer_processing',
          isRead: false,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      } catch (e) {
        console.error('Error processing transfer:', doc.id, e);
        await doc.ref.update({ status: 'failed', error: e.message });
      }
    }
  });

// ========================
// تحديث سعر الصرف (كل 6 ساعات)
// ========================
exports.updateExchangeRate = functions.pubsub
  .schedule('0 */6 * * *')
  .onRun(async (context) => {
    try {
      // استخدام ExchangeRate-API المجانية
      const response = await axios.get('https://api.exchangerate-api.com/v4/latest/EGP');
      const rate = response.data.rates['JOD'];

      await db.collection('exchangeRates').doc('EGP_JOD').set({
        rate: rate ?? 0.0133,
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        source: 'exchangerate-api',
      });

      console.log(`Exchange rate updated: 1 EGP = ${rate} JOD`);
    } catch (e) {
      console.error('Error updating exchange rate:', e);
      // استخدام سعر احتياطي
      await db.collection('exchangeRates').doc('EGP_JOD').set({
        rate: 0.0133,
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        source: 'fallback',
      });
    }
  });

// ========================
// إشعار عند إتمام الدفع
// ========================
exports.onPaymentReceived = functions.firestore
  .document('transactions/{transactionId}')
  .onUpdate(async (change, context) => {
    const newData = change.after.data();
    const oldData = change.before.data();

    if (newData.status !== 'completed' || oldData.status === 'completed') return;

    await db.collection('notifications').add({
      userId: newData.userId,
      title: 'تم استلام الدفع',
      body: `تم استلام دفع ${newData.amount} ج.م بنجاح`,
      type: 'payment_received',
      transactionId: context.params.transactionId,
      isRead: false,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  });
