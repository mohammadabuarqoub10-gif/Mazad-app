import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../providers/auth_provider.dart';

class SimpleBankSettingsScreen extends StatefulWidget {
  const SimpleBankSettingsScreen({super.key});

  @override
  State<SimpleBankSettingsScreen> createState() => _SimpleBankSettingsScreenState();
}

class _SimpleBankSettingsScreenState extends State<SimpleBankSettingsScreen> {
  final _nameController = TextEditingController();
  final _bankController = TextEditingController();
  final _ibanController = TextEditingController();
  bool _isSaving = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حسابي البنكي')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue[50],
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blue[200]!),
              ),
              child: Column(
                children: [
                  Icon(Icons.info, color: Colors.blue[600], size: 32),
                  const SizedBox(height: 8),
                  Text('كيف يعمل؟', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blue[800], fontSize: 18)),
                  const SizedBox(height: 8),
                  Text(
                    '١. تبيع منتج في المزاد\n٢. نأخذ 1% عمولة فقط\n٣. نحول الباقي لحسابك البنكي\n٤. تستلم أموالك بالدينار الأردني',
                    style: TextStyle(color: Colors.blue[700], height: 1.6),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _nameController,
              textAlign: TextAlign.right,
              decoration: InputDecoration(
                labelText: 'اسمك بالإنجليزي (كما في البنك)',
                hintText: 'Ahmed Mohamed',
                prefixIcon: const Icon(Icons.person),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _bankController,
              textAlign: TextAlign.right,
              decoration: InputDecoration(
                labelText: 'اسم البنك',
                hintText: 'مثال: البنك العربي',
                prefixIcon: const Icon(Icons.account_balance),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _ibanController,
              textAlign: TextAlign.left,
              textDirection: TextDirection.ltr,
              decoration: InputDecoration(
                labelText: 'رقم الحساب (IBAN)',
                hintText: 'JO89 ARAB 0000 0000 0000 0000 0000',
                prefixIcon: const Icon(Icons.numbers),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                helperText: 'الرقم اللي يبدأ بـ JO',
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _isSaving ? null : _save,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF6B4EE6),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: _isSaving
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('حفظ البيانات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.green[50], borderRadius: BorderRadius.circular(12)),
              child: Column(
                children: [
                  Text('مثال:', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green[800])),
                  const SizedBox(height: 8),
                  Text(
                    'إذا بعت بـ 10,000 جنيه مصري\nالعمولة: 100 جنيه (1%)\nصافي التحويل: 9,900 جنيه\nتستلم: تقريباً 132 دينار أردني',
                    style: TextStyle(color: Colors.green[700], height: 1.6),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (_nameController.text.isEmpty || _bankController.text.isEmpty || _ibanController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أملأ كل الحقول'), backgroundColor: Colors.red),
      );
      return;
    }

    setState(() => _isSaving = true);

    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final userId = authProvider.userModel?.id ?? authProvider.user?.uid;

      if (userId != null) {
        await FirebaseFirestore.instance.collection('users').doc(userId).update({
          'bankAccount': {
            'name': _nameController.text.trim(),
            'bankName': _bankController.text.trim(),
            'iban': _ibanController.text.trim().toUpperCase(),
          },
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم حفظ البيانات!'), backgroundColor: Colors.green),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ: $e'), backgroundColor: Colors.red),
      );
    }
    setState(() => _isSaving = false);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _bankController.dispose();
    _ibanController.dispose();
    super.dispose();
  }
}
