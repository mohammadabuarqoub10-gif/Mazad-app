import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import '../models/auction_model.dart';
import '../widgets/auction_card.dart';
import 'auction_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _searchController = TextEditingController();
  List<Auction> _results = [];
  bool _isSearching = false;
  String _query = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _searchController,
          autofocus: true,
          textAlign: TextAlign.right,
          style: const TextStyle(color: Colors.white),
          cursorColor: Colors.white,
          decoration: InputDecoration(
            hintText: 'ابحث عن مزاد...',
            hintStyle: const TextStyle(color: Colors.white70),
            border: InputBorder.none,
            filled: false,
            suffixIcon: _query.isNotEmpty
                ? IconButton(
                    icon: const Icon(Icons.clear, color: Colors.white),
                    onPressed: () {
                      _searchController.clear();
                      setState(() { _query = ''; _results = []; });
                    },
                  )
                : null,
          ),
          onChanged: (value) {
            setState(() => _query = value);
            if (value.length >= 2) _search(value);
          },
        ),
      ),
      body: _isSearching
          ? const Center(child: CircularProgressIndicator())
          : _query.isEmpty
              ? _buildSuggestions()
              : _results.isEmpty && _query.length >= 2
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.search_off, size: 64, color: Colors.grey[300]),
                          const SizedBox(height: 12),
                          Text('لا توجد نتائج لـ "$_query"',
                              style: TextStyle(color: Colors.grey[600])),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: _results.length,
                      itemBuilder: (context, index) => AuctionCard(
                        auction: _results[index],
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AuctionDetailScreen(auction: _results[index]),
                          ),
                        ),
                      ),
                    ),
    );
  }

  Widget _buildSuggestions() {
    final categories = ['سيارات', 'عقارات', 'إلكترونيات', 'أثاث', 'ملابس', 'تحف'];
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('تصفح الفئات', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: categories.map((cat) => ActionChip(
              label: Text(cat),
              onPressed: () {
                _searchController.text = cat;
                setState(() => _query = cat);
                _search(cat);
              },
            )).toList(),
          ),
        ],
      ),
    );
  }

  Future<void> _search(String query) async {
    setState(() => _isSearching = true);
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('auctions')
          .where('isActive', isEqualTo: true)
          .get();

      final lowerQuery = query.toLowerCase();
      final results = snapshot.docs
          .map((doc) => Auction.fromJson(doc.data(), doc.id))
          .where((a) =>
              a.title.toLowerCase().contains(lowerQuery) ||
              a.description.toLowerCase().contains(lowerQuery) ||
              a.category.toLowerCase().contains(lowerQuery) ||
              a.location.toLowerCase().contains(lowerQuery))
          .toList();

      setState(() { _results = results; _isSearching = false; });
    } catch (e) {
      setState(() => _isSearching = false);
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
