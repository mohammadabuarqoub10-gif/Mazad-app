import 'package:flutter/material.dart';

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('شروط الاستخدام')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _buildSection('١. قبول الشروط',
              'باستخدامك لتطبيق مزاد، فإنك توافق على الالتزام بهذه الشروط والأحكام. إذا كنت لا توافق على أي من هذه الشروط، يرجى عدم استخدام التطبيق.'),
          _buildSection('٢. آلية المزادات',
              'يتيح التطبيق للمستخدمين نشر منتجاتهم للبيع عبر المزاد العلني. تبدأ المزايدة بالسعر الابتدائي الذي يحدده البائع، ويفوز بالمزاد من يقدم أعلى سعر عند انتهاء المدة المحددة.'),
          _buildSection('٣. العمولة',
              'يحتسب التطبيق عمولة بنسبة 1% فقط من قيمة كل مزاد ناجح. تُخصم العمولة من مبلغ البائع تلقائياً عند اكتمال عملية البيع.'),
          _buildSection('٤. التزامات البائع',
              'يلتزم البائع بوصف المنتج بدقة وصدق، وتقديم صور حقيقية للمنتج، وإتمام عملية البيع عند فوز المشتري، والتواصل مع المشتري خلال 48 ساعة من انتهاء المزاد.'),
          _buildSection('٥. التزامات المشتري',
              'يلتزم المشتري الفائز بإتمام عملية الشراء ودفع المبلغ المتفق عليه خلال 48 ساعة من انتهاء المزاد. في حال التراجع، يحق للبائع الإبلاغ عن المشتري.'),
          _buildSection('٦. المدفوعات',
              'تتم المدفوعات عبر بوابة Paymob الآمنة. يدفع المشتري السعر النهائي للمزاد بالإضافة إلى عمولة التطبيق (1%). يُحول مبلغ البائع بعد خصم العمولة.'),
          _buildSection('٧. المنتجات المحظورة',
              'يُحظر نشر مزادات للمنتجات غير القانونية، أو المسروقة، أو المقلدة، أو التي تنتهك حقوق الملكية الفكرية. يحق للتطبيق إزالة أي مزاد يخالف هذه الشروط.'),
          _buildSection('٨. حل النزاعات',
              'في حال وجود نزاع بين البائع والمشتري، يتدخل فريق دعم التطبيق للمساعدة في الوصول لحل عادل. قرار فريق الدعم نهائي وملزم للطرفين.'),
          _buildSection('٩. تعديل الشروط',
              'يحق لتطبيق مزاد تعديل هذه الشروط في أي وقت. سيتم إشعار المستخدمين بالتغييرات الجوهرية عبر الإشعارات داخل التطبيق.'),
          const SizedBox(height: 20),
          Text(
            'آخر تحديث: يناير 2024',
            style: TextStyle(color: Colors.grey[500], fontSize: 12),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildSection(String title, String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(content, style: const TextStyle(height: 1.6, fontSize: 14)),
        ],
      ),
    );
  }
}
