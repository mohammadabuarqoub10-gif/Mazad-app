import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/auth_provider.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final userId = authProvider.userModel?.id ?? authProvider.user?.uid;

    if (userId == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('الإشعارات')),
        body: const Center(child: Text('يجب تسجيل الدخول أولاً')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('الإشعارات'),
        actions: [
          TextButton(
            onPressed: () => _markAllRead(userId),
            child: const Text('قراءة الكل', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('notifications')
            .where('userId', isEqualTo: userId)
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.notifications_none, size: 80, color: Colors.grey[300]),
                  const SizedBox(height: 16),
                  Text('لا توجد إشعارات', style: TextStyle(color: Colors.grey[600], fontSize: 18)),
                ],
              ),
            );
          }

          final docs = snapshot.data!.docs;
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final data = docs[index].data() as Map<String, dynamic>;
              final isRead = data['isRead'] ?? false;
              final createdAt = (data['createdAt'] as Timestamp?)?.toDate();

              return Dismissible(
                key: Key(docs[index].id),
                direction: DismissDirection.endToStart,
                background: Container(
                  color: Colors.red,
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 16),
                  child: const Icon(Icons.delete, color: Colors.white),
                ),
                onDismissed: (_) => docs[index].reference.delete(),
                child: ListTile(
                  tileColor: isRead ? null : const Color(0xFF6B4EE6).withOpacity(0.05),
                  leading: CircleAvatar(
                    backgroundColor: _getNotifColor(data['type']).withOpacity(0.15),
                    child: Icon(_getNotifIcon(data['type']), color: _getNotifColor(data['type'])),
                  ),
                  title: Text(
                    data['title'] ?? '',
                    style: TextStyle(fontWeight: isRead ? FontWeight.normal : FontWeight.bold),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(data['body'] ?? ''),
                      if (createdAt != null)
                        Text(
                          DateFormat('yyyy/MM/dd HH:mm').format(createdAt),
                          style: TextStyle(color: Colors.grey[500], fontSize: 11),
                        ),
                    ],
                  ),
                  isThreeLine: true,
                  onTap: () {
                    if (!isRead) {
                      docs[index].reference.update({'isRead': true});
                    }
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }

  IconData _getNotifIcon(String? type) {
    switch (type) {
      case 'new_bid': return Icons.gavel;
      case 'auction_won': return Icons.emoji_events;
      case 'auction_sold': return Icons.sell;
      case 'bank_transfer_processing': return Icons.account_balance;
      case 'payment_received': return Icons.payments;
      default: return Icons.notifications;
    }
  }

  Color _getNotifColor(String? type) {
    switch (type) {
      case 'new_bid': return Colors.blue;
      case 'auction_won': return Colors.amber;
      case 'auction_sold': return Colors.green;
      case 'bank_transfer_processing': return Colors.purple;
      case 'payment_received': return Colors.teal;
      default: return Colors.grey;
    }
  }

  Future<void> _markAllRead(String userId) async {
    final batch = FirebaseFirestore.instance.batch();
    final unread = await FirebaseFirestore.instance
        .collection('notifications')
        .where('userId', isEqualTo: userId)
        .where('isRead', isEqualTo: false)
        .get();
    for (final doc in unread.docs) {
      batch.update(doc.reference, {'isRead': true});
    }
    await batch.commit();
  }
}
