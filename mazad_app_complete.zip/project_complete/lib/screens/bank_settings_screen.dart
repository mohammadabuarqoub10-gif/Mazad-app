import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/bank_transfer_service.dart';
import '../providers/auth_provider.dart';

class BankSettingsScreen extends StatefulWidget {
  const BankSettingsScreen({super.key});

  @override
  State<BankSettingsScreen> createState() => _BankSettingsScreenState();
}

class _BankSettingsScreenState extends State<BankSettingsScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _ibanController = TextEditingController();
  final _bankNameController = TextEditingController();
  final _accountNumberController = TextEditingController();

  bool _isLoading = false;
  bool _isFetchingData = true;
  bool _autoConvert = true;
  bool _autoTransfer = false;
  double _minTransferAmount = 100;

  @override
  void initState() {
    super.initState();
    _loadExistingData();
  }

  Future<void> _loadExistingData() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final userId = authProvider.userModel?.id ?? authProvider.user?.uid;
    if (userId == null) { setState(() => _isFetchingData = false); return; }

    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(userId).get();
      if (doc.exists) {
        final data = doc.data()!;
        final bankAccount = data['bankAccount'] as Map<String, dynamic>?;
        if (bankAccount != null) {
          _nameController.text = bankAccount['name'] ?? '';
          _bankNameController.text = bankAccount['bankName'] ?? '';
          _ibanController.text = bankAccount['iban'] ?? '';
          _accountNumberController.text = bankAccount['accountNumber'] ?? '';
        }
        setState(() {
          _autoConvert = data['autoConvert'] ?? true;
          _autoTransfer = data['autoTransfer'] ?? false;
          _minTransferAmount = (data['minTransferAmount'] ?? 100).toDouble();
        });
      }
    } catch (_) {}
    setState(() => _isFetchingData = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_isFetchingData) {
      return Scaffold(appBar: AppBar(title: const Text('إعدادات الحساب البنكي')),
          body: const Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('إعدادات الحساب البنكي')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // إعدادات التحويل التلقائي
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    children: [
                      SwitchListTile(
                        title: const Text('تحويل تلقائي للعملة (EGP → JOD)'),
                        value: _autoConvert,
                        activeColor: const Color(0xFF6B4EE6),
                        onChanged: (v) => setState(() => _autoConvert = v),
                      ),
                      const Divider(height: 1),
                      SwitchListTile(
                        title: const Text('إرسال تلقائي للبنك'),
                        subtitle: const Text('إرسال المبالغ لحسابك تلقائياً'),
                        value: _autoTransfer,
                        activeColor: const Color(0xFF6B4EE6),
                        onChanged: (v) => setState(() => _autoTransfer = v),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        title: const Text('الحد الأدنى للتحويل'),
                        subtitle: Text('${_minTransferAmount.toInt()} JOD'),
                        trailing: IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: _showMinAmountDialog,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              Text('معلومات الحساب البنكي (الأردن)',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),

              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: 'اسم صاحب الحساب *', prefixIcon: Icon(Icons.person)),
                validator: (v) => (v == null || v.isEmpty) ? 'الاسم مطلوب' : null,
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _bankNameController,
                decoration: const InputDecoration(labelText: 'اسم البنك *', prefixIcon: Icon(Icons.account_balance)),
                validator: (v) => (v == null || v.isEmpty) ? 'اسم البنك مطلوب' : null,
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _ibanController,
                textDirection: TextDirection.ltr,
                textAlign: TextAlign.left,
                decoration: const InputDecoration(
                  labelText: 'IBAN *',
                  hintText: 'JO89 ARAB 0000 0000 0000 0000 0000',
                  prefixIcon: Icon(Icons.confirmation_number),
                  helperText: 'رقم الحساب الدولي - يبدأ بـ JO',
                ),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'IBAN مطلوب';
                  if (!v.toUpperCase().startsWith('JO')) return 'يجب أن يبدأ بـ JO';
                  return null;
                },
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _accountNumberController,
                textDirection: TextDirection.ltr,
                textAlign: TextAlign.left,
                decoration: const InputDecoration(
                  labelText: 'رقم الحساب المحلي (اختياري)',
                  prefixIcon: Icon(Icons.numbers),
                ),
              ),

              const SizedBox(height: 20),

              // سعر الصرف
              FutureBuilder<double>(
                future: BankTransferService.getExchangeRate(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) return const LinearProgressIndicator();
                  final rate = snapshot.data!;
                  return Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.green[50],
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.green[200]!),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.currency_exchange, color: Colors.green[700]),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('سعر الصرف الحالي', style: TextStyle(color: Colors.green[800], fontWeight: FontWeight.bold)),
                            Text('1 EGP = ${rate.toStringAsFixed(5)} JOD', style: TextStyle(color: Colors.green[700], fontSize: 16, fontWeight: FontWeight.bold)),
                            Text('1 JOD = ${(1 / rate).toStringAsFixed(2)} EGP', style: TextStyle(color: Colors.green[600])),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),

              const SizedBox(height: 24),

              // حاسبة التحويل
              _buildConversionCalculator(),

              const SizedBox(height: 28),

              // زر الحفظ
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _saveSettings,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6B4EE6),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: _isLoading
                      ? const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                          SizedBox(width: 12),
                          Text('جاري الحفظ...'),
                        ])
                      : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.save),
                          SizedBox(width: 8),
                          Text('حفظ الإعدادات', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                        ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildConversionCalculator() {
    final egpController = TextEditingController();
    final jodController = TextEditingController();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('حاسبة التحويل', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: egpController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: 'المبلغ (EGP)', suffixText: 'ج.م', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
                    onChanged: (value) async {
                      final egp = double.tryParse(value) ?? 0;
                      final result = await BankTransferService.convertEgpToJod(egp);
                      jodController.text = result['jodAmount'].toStringAsFixed(2);
                    },
                  ),
                ),
                const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Icon(Icons.arrow_forward, color: Colors.grey)),
                Expanded(
                  child: TextField(
                    controller: jodController,
                    readOnly: true,
                    decoration: InputDecoration(
                      labelText: 'المبلغ (JOD)',
                      suffixText: 'د.أ',
                      filled: true,
                      fillColor: Colors.grey[100],
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showMinAmountDialog() {
    final controller = TextEditingController(text: _minTransferAmount.toInt().toString());
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('الحد الأدنى للتحويل'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'المبلغ (JOD)', suffixText: 'د.أ'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () {
              setState(() => _minTransferAmount = double.tryParse(controller.text) ?? 100);
              Navigator.pop(context);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  Future<void> _saveSettings() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final userId = authProvider.userModel?.id ?? authProvider.user?.uid;
      if (userId == null) throw Exception('غير مسجل الدخول');

      await FirebaseFirestore.instance.collection('users').doc(userId).update({
        'bankAccount': {
          'name': _nameController.text.trim(),
          'bankName': _bankNameController.text.trim(),
          'iban': _ibanController.text.trim().toUpperCase(),
          'accountNumber': _accountNumberController.text.trim(),
        },
        'autoConvert': _autoConvert,
        'autoTransfer': _autoTransfer,
        'minTransferAmount': _minTransferAmount,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم حفظ الإعدادات بنجاح!'), backgroundColor: Colors.green),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ في الحفظ: $e'), backgroundColor: Colors.red),
      );
    }
    setState(() => _isLoading = false);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _ibanController.dispose();
    _bankNameController.dispose();
    _accountNumberController.dispose();
    super.dispose();
  }
}
