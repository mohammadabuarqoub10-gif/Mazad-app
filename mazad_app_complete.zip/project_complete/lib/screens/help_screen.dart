import 'package:flutter/material.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مركز المساعدة')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // بطاقة التواصل
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  const Icon(Icons.headset_mic, size: 48, color: Color(0xFF6B4EE6)),
                  const SizedBox(height: 12),
                  const Text('تواصل معنا', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('نحن هنا لمساعدتك 7 أيام في الأسبوع', style: TextStyle(color: Colors.grey[600])),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.email_outlined),
                          label: const Text('البريد الإلكتروني'),
                          onPressed: () {},
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.chat),
                          label: const Text('واتساب'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            foregroundColor: Colors.white,
                          ),
                          onPressed: () {},
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          const Text('الأسئلة الشائعة',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),

          _buildFaq('كيف أنشر مزاداً؟',
              'اضغط على زر "مزاد جديد" في الصفحة الرئيسية، ثم أدخل تفاصيل المنتج (الصور، الاسم، الفئة، السعر الابتدائي، المدة) واضغط "نشر المزاد".'),
          _buildFaq('كيف أقدم مزايدة؟',
              'ادخل على صفحة المزاد واضغط على حقل "أدخل مبلغ المزايدة"، أدخل مبلغاً أعلى من السعر الحالي ثم اضغط "مزايدة".'),
          _buildFaq('كم تبلغ عمولة التطبيق؟',
              'عمولة التطبيق 1% فقط من قيمة المزاد. مثال: إذا بعت بـ 10,000 ج.م، العمولة 100 ج.م فقط.'),
          _buildFaq('متى أستلم أموال البيع؟',
              'بعد انتهاء المزاد وإتمام المشتري للدفع، يتم تحويل مبلغك (بعد خصم العمولة) إلى حسابك البنكي خلال 2-3 أيام عمل.'),
          _buildFaq('كيف أتواصل مع البائع؟',
              'في صفحة تفاصيل المزاد ستجد معلومات البائع مع زر الاتصال المباشر.'),
          _buildFaq('ماذا لو لم يتمم المشتري الدفع؟',
              'إذا لم يدفع المشتري الفائز خلال 48 ساعة، يمكنك الإبلاغ عنه من خلال صفحة المزاد وسيتم التواصل معك من فريق الدعم.'),
          _buildFaq('هل التطبيق آمن؟',
              'نعم، جميع المدفوعات تتم عبر بوابة Paymob الآمنة ومشفرة بالكامل. معلوماتك الشخصية محمية ولا تشارك مع أطراف ثالثة.'),
        ],
      ),
    );
  }

  Widget _buildFaq(String question, String answer) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ExpansionTile(
        title: Text(question, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        iconColor: const Color(0xFF6B4EE6),
        collapsedIconColor: Colors.grey,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Text(answer, style: const TextStyle(height: 1.6, fontSize: 14)),
          ),
        ],
      ),
    );
  }
}
