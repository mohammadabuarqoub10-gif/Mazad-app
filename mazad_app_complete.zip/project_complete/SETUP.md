# 🚀 دليل إعداد وتشغيل تطبيق مزاد

## المتطلبات الأساسية
- Flutter 3.0+
- Dart 3.0+
- Node.js 18+
- حساب Firebase

---

## الخطوة 1: إنشاء مشروع Flutter

```bash
flutter create mazad_app
cd mazad_app
```

## الخطوة 2: نسخ ملفات المشروع

انسخ محتويات هذا المجلد إلى مجلد `mazad_app`، واستبدل الملفات الموجودة.

## الخطوة 3: تثبيت الحزم

```bash
flutter pub get
```

## الخطوة 4: إعداد Firebase

### أ. إنشاء مشروع Firebase
1. اذهب إلى [Firebase Console](https://console.firebase.google.com)
2. أنشئ مشروعاً جديداً باسم `mazad-app`
3. فعّل **Firestore Database** (ابدأ في وضع Test Mode)
4. فعّل **Firebase Storage**
5. فعّل **Firebase Authentication** → Phone
6. فعّل **Firebase Cloud Messaging**

### ب. إضافة التطبيق لـ Firebase
```bash
# تثبيت Firebase CLI
npm install -g firebase-tools
firebase login

# إضافة Firebase لمشروع Flutter
dart pub global activate flutterfire_cli
flutterfire configure
```

هذا سيُنشئ ملف `lib/firebase_options.dart` تلقائياً.

### ج. تحديث main.dart
استبدل في `lib/main.dart`:
```dart
import 'firebase_options.dart';
// ...
await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
```

## الخطوة 5: إعداد Paymob

1. سجّل في [Paymob](https://paymob.com)
2. احصل على: API Key, Integration ID, Wallet Integration ID, iFrame ID
3. حدّث `lib/constants.dart`:
```dart
static const String paymobApiKey = 'YOUR_ACTUAL_KEY';
static const String paymobIntegrationId = 'YOUR_INTEGRATION_ID';
// ...
```

## الخطوة 6: نشر قواعد Firestore

```bash
firebase deploy --only firestore:rules
firebase deploy --only storage
```

## الخطوة 7: نشر Cloud Functions

```bash
cd firebase/functions
npm install
cd ../..
firebase deploy --only functions
```

## الخطوة 8: تشغيل التطبيق

```bash
flutter run
```

---

## إعداد خاصية Wise (للتحويلات البنكية)

1. سجّل في [Wise Business](https://wise.com/business)
2. احصل على API Key
3. حدّث متغيرات Firebase Functions:
```bash
firebase functions:config:set wise.api_key="YOUR_WISE_KEY"
```
4. أزل تعليق كود Wise في `firebase/functions/index.js`

---

## هيكل قاعدة البيانات (Firestore)

```
users/
  {userId}/
    name, phone, email, isVerified
    bankAccount: { name, bankName, iban }
    autoTransfer, autoConvert, minTransferAmount
    auctionsCreated, auctionsWon

auctions/
  {auctionId}/
    title, description, images[]
    startPrice, currentPrice, category, condition
    sellerId, sellerName, sellerPhone
    endTime, isActive, bidCount, viewCount
    bids[]: { userId, userName, amount, time }
    winnerId, winnerName, commission, sellerAmount

transactions/
  {transactionId}/
    userId, auctionId, amount, type, status

commissions/
  {commissionId}/
    auctionId, amount, jodAmount, exchangeRate, status

bankTransfers/
  {transferId}/
    userId, egpAmount, jodAmount, status, bankAccount

notifications/
  {notificationId}/
    userId, title, body, type, isRead, createdAt

exchangeRates/
  EGP_JOD/
    rate, timestamp, source
```

---

## البناء للنشر

```bash
# Android
flutter build appbundle --release

# iOS
flutter build ios --release

# لرفعه على Google Play / App Store
```

---

## الدعم
- البريد: support@mazad.app
- الوثائق: docs/API.md
